from dataclasses import dataclass, field
from typing import Any, Optional, Tuple

import torch

from core.device import get_best_device
from core.llm_defaults import DEFAULT_LLM_PROVIDER, get_provider_sampling_defaults


@dataclass
class DetectionConfig:
    """Configuration for speech bubble detection."""

    confidence: float = 0.6
    conjoined_confidence: float = 0.35
    panel_confidence: float = 0.25
    seg_model: str = "yolo"  # "sam3", "sam2", or "yolo"
    bubble_detector_model: str = "yolo_2"  # "yolo_1" or "yolo_2"
    conjoined_detection: bool = True
    use_panel_sorting: bool = True
    use_osb_text_verification: bool = True


@dataclass
class CleaningConfig:
    """Configuration for speech bubble cleaning."""

    thresholding_value: int = 200
    use_otsu_threshold: bool = False
    roi_shrink_px: int = 5
    inpaint_colored_bubbles: bool = False


_DEFAULT_TRANSLATION_PROVIDER = DEFAULT_LLM_PROVIDER
_DEFAULT_SAMPLING = get_provider_sampling_defaults(_DEFAULT_TRANSLATION_PROVIDER)


@dataclass
class TranslationConfig:
    """Configuration for text translation."""

    provider: str = _DEFAULT_TRANSLATION_PROVIDER
    google_api_key: str = ""
    openai_api_key: str = ""
    anthropic_api_key: str = ""
    xai_api_key: str = ""
    deepseek_api_key: str = ""
    zai_api_key: str = ""
    moonshot_api_key: str = ""
    mimo_api_key: str = ""
    openrouter_api_key: str = ""
    openai_compatible_url: str = "http://localhost:8080/v1"
    openai_compatible_api_key: Optional[str] = ""
    model_name: str = "gemini-3.1-flash-lite"
    provider_models: dict[str, Optional[str]] = field(default_factory=dict)
    temperature: float = float(_DEFAULT_SAMPLING["temperature"])
    top_p: float = float(_DEFAULT_SAMPLING["top_p"])
    top_k: int = int(_DEFAULT_SAMPLING["top_k"])
    max_tokens: Optional[int] = (
        None  # None = use default logic (16384 for reasoning, 4096 otherwise)
    )
    input_language: str = "Japanese"
    output_language: str = "English"
    reading_direction: str = "rtl"
    translation_mode: str = "one-step"
    reasoning_effort: Optional[str] = (
        None  # Default: Google uses "auto", Anthropic uses "none", others use "medium"
    )
    effort: Optional[str] = (
        None  # Opus 4.5+, Sonnet 4.6 only: token spending eagerness (xhigh/high/medium/low)
    )
    verbosity: Optional[str] = (
        None  # GPT-5 series only: controls response verbosity (high/medium/low)
    )
    send_full_page_context: bool = True
    whiteout_conjoined_bubbles: bool = True
    upscale_method: str = "model_lite"  # "model", "model_lite", "lanczos", or "none"
    enable_web_search: bool = False  # Enable model's built-in web search for up-to-date information. OpenRouter uses its own web search tool.
    enable_code_execution: bool = False  # Enable Gemini's code execution tool for image zoom/inspection (Gemini 3 Flash only)
    use_custom_sampling: bool = True
    image_detail: str = "auto"  # OpenAI image detail (auto/high/low/original)
    media_resolution: str = (
        "auto"  # Only available via Google provider (auto/high/medium/low)
    )
    media_resolution_bubbles: str = "auto"  # Gemini 3 and SpaceXAI models
    media_resolution_context: str = "auto"  # Gemini 3 and SpaceXAI models
    bubble_min_side_pixels: int = 128
    context_image_max_side_pixels: int = 1024
    previous_context_image_count: int = 0
    previous_context_text_count: int = 0
    osb_min_side_pixels: int = 128
    special_instructions: Optional[str] = None
    ocr_method: str = "LLM"  # "LLM", "manga-ocr", "paddleocr-vl-1.6", "paddleocr-classic", or "paddleocr-classic-v5"
    request_coordinator: Optional[Any] = None


@dataclass
class RenderingConfig:
    """Configuration for rendering translated text."""

    font_dir: str = "./fonts"
    max_font_size: int = 16
    min_font_size: int = 8
    line_spacing_mult: float = 1.0
    use_subpixel_rendering: bool = False
    font_hinting: str = "none"
    use_ligatures: bool = False
    hyphenate_before_scaling: bool = True
    hyphen_penalty: float = 1000.0
    hyphenation_min_word_length: int = 8
    badness_exponent: float = 3.0
    padding_pixels: float = 4.0
    outline_width: float = 0.0
    supersampling_factor: int = 4
    detach_trailing_punctuation: bool = True
    auto_vertical_text: bool = False

    # --- Copy the original lettering style ---
    # When enabled, the fill colour, keyline colour and width, glow colour and
    # radius, and font size of the *source* text are measured off the untouched
    # page and reused for the translation. Anything that cannot be measured
    # confidently keeps the value configured above, so a failed read degrades to
    # ordinary rendering instead of to a wrong-looking page.
    match_original_style: bool = False
    # How much larger than the measured original the text may be set, as a
    # fraction. The measured size becomes a ceiling, not a fixed size: the layout
    # engine still shrinks text that no longer fits once translated.
    match_original_style_tolerance: float = 0.25
    # Measurements scoring below this confidence are discarded.
    match_original_style_min_confidence: float = 0.35

    # Per-region style values, normally filled in from the measurement above
    # rather than configured by hand. None means "decide as usual".
    outline_color_rgb: Optional[Tuple[int, int, int]] = None
    glow_color_rgb: Optional[Tuple[int, int, int]] = None
    glow_radius: float = 0.0


@dataclass
class OutsideTextConfig:
    """Configuration for outside speech bubble text detection and removal."""

    enabled: bool = False
    enable_page_number_filtering: bool = False
    page_filter_margin_threshold: float = 0.1
    page_filter_min_area_ratio: float = 0.05
    min_area_ignore_ratio: float = 0.0
    seed: int = 1  # -1 = random
    huggingface_token: str = ""  # Required for Flux Kontext model downloads
    inpainting_method: str = (
        "flux_klein_4b"  # flux_klein_9b, flux_klein_4b, flux_kontext, sdxl, lama, opencv, none
    )
    flux_backend: str = "sdnq"  # "sdcpp", "sdnq", "nunchaku" (Kontext only)
    flux_low_vram: bool = False  # Use CPU offload for SDNQ
    flux_sdcpp_cache_mode: str = "none"
    flux_sdcpp_diffusion_quant: str = "Q4_K_M"
    flux_sdcpp_text_encoder_quant: str = ""
    flux_num_inference_steps: int = 8
    flux_luminance_correction: bool = (
        True  # Match patch luminance to surrounding context
    )
    flux_upscale_small_crops: bool = True
    flux_group_regions: bool = False
    flux_residual_diff_threshold: float = 0.15
    sdxl_guidance_scale: float = 6.5  # CFG strength for SDXL inpainting (lower = cleaner at low step counts)
    sdxl_strength: float = 0.99  # Denoise strength within the OSB mask (0.99 = near-full art regen)
    osb_confidence: float = 0.6
    osb_model_variant: str = "manga"  # "manga" (default, deepghs YOLOv12) or "webtoon" (ogkalu YOLOv8, tuned for long-strip manhwa)
    osb_font_dir: Optional[str] = None  # None = use main font as fallback
    osb_max_font_size: int = 64
    osb_min_font_size: int = 10
    osb_use_ligatures: bool = False
    osb_outline_width: float = 3.0
    osb_line_spacing: float = 1.0
    osb_use_subpixel_rendering: bool = False
    osb_font_hinting: str = "none"
    bbox_expansion_percent: float = 0.1
    osb_render_expansion_narrow_multiplier: float = 1.0
    osb_render_expansion_tiny_multiplier: float = 1.0
    osb_render_expansion_aspect_ratio_threshold: float = 0.4
    osb_render_expansion_area_ratio_threshold: float = 0.005
    text_box_proximity_ratio: float = 0.02  # 2% of image dimension
    flux_guidance_scale: float = 2.5
    flux_prompt: str = "Remove all text."
    # When True, OSB regions the LLM tags as sound-effect (SFX) text are left
    # completely untouched: no inpainting, no rendering. Only applies to
    # outside-bubble (OSB) text; speech bubbles and captions are never skipped.
    sfx_skip_inpaint: bool = True


@dataclass
class OutputConfig:
    """Configuration for saving output images."""

    jpeg_quality: int = 95
    png_compression: int = 2
    output_format: str = "png"
    upscale_final_image: bool = False
    image_upscale_factor: float = 2.0
    image_upscale_model: str = "model_lite"  # "model" or "model_lite"


@dataclass
class MangaTranslatorConfig:
    """Main configuration for the MangaTranslator pipeline."""

    yolo_model_path: str
    detection: DetectionConfig = field(default_factory=DetectionConfig)
    cleaning: CleaningConfig = field(default_factory=CleaningConfig)
    translation: TranslationConfig = field(default_factory=TranslationConfig)
    rendering: RenderingConfig = field(default_factory=RenderingConfig)
    output: OutputConfig = field(default_factory=OutputConfig)
    outside_text: OutsideTextConfig = field(default_factory=OutsideTextConfig)
    preprocessing: "PreprocessingConfig" = field(
        default_factory=lambda: PreprocessingConfig()
    )
    verbose: bool = False
    device: Optional[torch.device] = None
    cleaning_only: bool = False
    upscaling_only: bool = False
    test_mode: bool = False
    processing_scale: float = 1.0
    parallel_requests: int = 1
    batch_parallel_within_pages: bool = False
    overlap_llm_with_inpaint: bool = False
    retry_failed_once: bool = False
    request_coordinator: Optional[Any] = None

    def __post_init__(self):
        # Load API keys from environment variables if not already set
        import os

        if not self.translation.google_api_key:
            self.translation.google_api_key = os.environ.get(
                "GOOGLE_API_KEY"
            ) or os.environ.get("GEMINI_API_KEY", "")
        if not self.translation.openai_api_key:
            self.translation.openai_api_key = os.environ.get("OPENAI_API_KEY", "")
        if not self.translation.anthropic_api_key:
            self.translation.anthropic_api_key = os.environ.get("ANTHROPIC_API_KEY", "")
        if not self.translation.xai_api_key:
            self.translation.xai_api_key = os.environ.get(
                "SPACEXAI_API_KEY"
            ) or os.environ.get("XAI_API_KEY", "")
        if not self.translation.deepseek_api_key:
            self.translation.deepseek_api_key = os.environ.get("DEEPSEEK_API_KEY", "")
        if not self.translation.zai_api_key:
            self.translation.zai_api_key = os.environ.get("ZAI_API_KEY", "")
        if not self.translation.moonshot_api_key:
            self.translation.moonshot_api_key = os.environ.get("MOONSHOT_API_KEY", "")
        if not self.translation.mimo_api_key:
            self.translation.mimo_api_key = os.environ.get("MIMO_API_KEY", "")
        if not self.translation.openrouter_api_key:
            self.translation.openrouter_api_key = os.environ.get(
                "OPENROUTER_API_KEY", ""
            )
        if (
            not self.translation.openai_compatible_api_key
        ):  # Check if it's None or empty string
            self.translation.openai_compatible_api_key = os.environ.get(
                "OPENAI_COMPATIBLE_API_KEY", ""
            )
        if not self.outside_text.huggingface_token:
            self.outside_text.huggingface_token = os.environ.get("HF_TOKEN", "")

        # Autodetect device if not specified
        if self.device is None:
            self.device = get_best_device()


@dataclass
class PreprocessingConfig:
    """Configuration for image preprocessing before detection/cleaning."""

    enabled: bool = False
    factor: float = 2.0
    auto_scale: bool = True


def calculate_reasoning_budget(total_tokens: int, effort_level: str) -> int:
    """
    Calculate reasoning token budget based on effort level.

    Args:
        total_tokens: Total available tokens (typically max_tokens)
        effort_level: Reasoning effort level ("high", "medium", "low", "minimal", "auto", or "none")

    Returns:
        int: Calculated budget in tokens
        - "high": 80% of total_tokens
        - "medium": 50% of total_tokens
        - "low": 20% of total_tokens
        - "minimal": 10% of total_tokens
        - "auto" or "none": Returns 0 (caller should handle these cases separately)
    """
    if effort_level == "high":
        return int(total_tokens * 0.8)
    elif effort_level == "medium":
        return int(total_tokens * 0.5)
    elif effort_level == "low":
        return int(total_tokens * 0.2)
    elif effort_level == "minimal":
        return int(total_tokens * 0.1)
    else:
        # "auto" or "none" - return 0, caller should handle these cases
        return 0
