import math
from typing import Dict, Optional, Tuple

import cv2
import numpy as np
import torch
from PIL import Image, ImageFilter
from scipy.ndimage import distance_transform_edt

from core.caching import get_cache
from core.device import empty_cache, get_best_device, get_best_dtype
from core.ml.model_manager import get_model_manager
from core.ml.sdcpp_server import pil_to_base64_png, run_image_job
from utils.exceptions import ModelError
from utils.logging import log_message
from utils.model_metadata import (
    flux_sdcpp_quant_default,
    flux_sdcpp_text_encoder_default,
)

# Blur Parameters
BLUR_SCALE_FACTOR = (
    0.1  # Multiplier for bounding box dimensions to calculate blur radius
)
MIN_BLUR_RADIUS = 1  # Minimum blur radius in pixels
MAX_BLUR_RADIUS = 10  # Maximum blur radius in pixels

# Inpainting Parameters
FLUX_GUIDANCE_SCALE = 2.5  # Flux Kontext guidance scale
CONTEXT_PADDING_RATIO = 0.5  # Context padding is 50% of detection size
MAX_CONTEXT_PADDING = 80  # Context padding capped at 80 pixels

# OpenCV texture-inpainting parameters (lightweight, no-GPU fallback / "opencv" method)
CV2_INPAINT_RADIUS = 9  # Radius of circular neighborhood used by cv2.inpaint (larger = smoother texture continuity, less streaking on halftone/gradient backgrounds)
CV2_MASK_DILATE_PX = 4  # Grow the OCR mask slightly so glyph edges/anti-aliasing are fully erased
CV2_INPAINT_CONTEXT_PADDING = 32  # Extra border of real pixels fed to cv2.inpaint for better texture context


def opencv_texture_inpaint(
    pil_image: "Image.Image",
    mask_np: np.ndarray,
    method: str = "telea",
    radius: int = CV2_INPAINT_RADIUS,
    dilate_px: int = CV2_MASK_DILATE_PX,
    bbox: Optional[Tuple[int, int, int, int]] = None,
    context_padding: int = CV2_INPAINT_CONTEXT_PADDING,
    verbose: bool = False,
) -> "Image.Image":
    """
    Texture-aware OSB/SFX text removal using OpenCV's classic inpainting
    (Telea or Navier-Stokes). Unlike a flat color fill, this reconstructs the
    surrounding artwork (patterns, gradients, wood grain, fabric, etc.) so the
    erased text region blends back into the art instead of covering it with a
    solid rectangle.

    Args:
        pil_image: Full-page PIL image (RGB) to inpaint.
        mask_np: Boolean (or 0/255) array, same H/W as pil_image, True/255
            where the original text pixels are and should be erased.
        method: "telea" (cv2.INPAINT_TELEA) or "ns" (cv2.INPAINT_NS).
        radius: Inpainting radius passed to cv2.inpaint.
        dilate_px: How many pixels to grow the mask by before inpainting, so
            anti-aliased glyph edges don't leave faint text ghosts behind.
        bbox: Optional (x1, y1, x2, y2) of the text region. When given, only a
            padded crop around it is sent through cv2.inpaint (much faster on
            large pages); the result is pasted back using the mask so nothing
            outside the mask is touched.
        context_padding: Extra pixels of real artwork included around bbox so
            cv2.inpaint has enough surrounding texture to draw from.
        verbose: Enable debug logging.

    Returns:
        A new PIL.Image with the masked text pixels erased and the
        surrounding artwork reconstructed. If nothing needs inpainting (empty
        mask) the original image is returned unchanged.
    """
    if pil_image is None:
        return pil_image

    img_w, img_h = pil_image.size
    mask_bool = mask_np.astype(bool)
    if not np.any(mask_bool):
        return pil_image

    flag = cv2.INPAINT_NS if method == "ns" else cv2.INPAINT_TELEA

    if bbox is not None:
        x1, y1, x2, y2 = [int(v) for v in bbox]
        cx1 = max(0, x1 - context_padding)
        cy1 = max(0, y1 - context_padding)
        cx2 = min(img_w, x2 + context_padding)
        cy2 = min(img_h, y2 + context_padding)
    else:
        ys, xs = np.where(mask_bool)
        if ys.size == 0:
            return pil_image
        cx1 = max(0, int(xs.min()) - context_padding)
        cy1 = max(0, int(ys.min()) - context_padding)
        cx2 = min(img_w, int(xs.max()) + 1 + context_padding)
        cy2 = min(img_h, int(ys.max()) + 1 + context_padding)

    if cx2 <= cx1 or cy2 <= cy1:
        return pil_image

    crop_pil = pil_image.crop((cx1, cy1, cx2, cy2)).convert("RGB")
    crop_bgr = cv2.cvtColor(np.array(crop_pil), cv2.COLOR_RGB2BGR)

    local_mask = mask_bool[cy1:cy2, cx1:cx2]
    if not np.any(local_mask):
        return pil_image

    local_mask_u8 = (local_mask.astype(np.uint8)) * 255
    if dilate_px > 0:
        kernel = cv2.getStructuringElement(
            cv2.MORPH_ELLIPSE, (dilate_px * 2 + 1, dilate_px * 2 + 1)
        )
        local_mask_u8 = cv2.dilate(local_mask_u8, kernel, iterations=1)

    try:
        # Run both algorithms and blend: Telea preserves edges/structure better,
        # NS handles smooth gradients/halftone better. Blending avoids the harsh
        # directional streaking either produces alone on complex manga textures.
        inpainted_telea = cv2.inpaint(crop_bgr, local_mask_u8, radius, cv2.INPAINT_TELEA)
        inpainted_ns = cv2.inpaint(crop_bgr, local_mask_u8, radius, cv2.INPAINT_NS)
        inpainted_bgr = cv2.addWeighted(inpainted_telea, 0.5, inpainted_ns, 0.5, 0)

        # Light median blur restricted to the masked area only: removes residual
        # streak/noise artifacts from the inpaint fill without softening real
        # artwork outside the mask.
        smoothed = cv2.medianBlur(inpainted_bgr, 5)
        mask_3ch = cv2.cvtColor(local_mask_u8, cv2.COLOR_GRAY2BGR).astype(bool)
        inpainted_bgr = np.where(mask_3ch, smoothed, inpainted_bgr)
    except Exception as e:
        log_message(
            f"cv2.inpaint failed ({e}); returning original crop unchanged",
            verbose=verbose,
        )
        return pil_image

    inpainted_rgb = cv2.cvtColor(inpainted_bgr, cv2.COLOR_BGR2RGB)
    inpainted_crop_pil = Image.fromarray(inpainted_rgb)

    result = pil_image.copy()
    # Paste only the (dilated) masked pixels back, so any anti-aliasing at the
    # crop boundary from cv2.inpaint never bleeds into untouched artwork.
    # Feather the paste mask edge by 1-2px so the inpaint patch blends into
    # surrounding art instead of leaving a visible hard seam/outline.
    paste_mask_pil = Image.fromarray(local_mask_u8, mode="L").filter(
        ImageFilter.GaussianBlur(radius=1.2)
    )
    result.paste(inpainted_crop_pil, (cx1, cy1), mask=paste_mask_pil)

    log_message(
        f"OpenCV {method.upper()} inpaint applied to {cx2 - cx1}x{cy2 - cy1} region",
        verbose=verbose,
    )
    return result


# LaMa (Large Mask Inpainting) parameters — lightweight CNN inpainter, usable
# speed on CPU (no GPU required), much better texture quality than OpenCV on
# complex manga backgrounds (halftone, gradients, screentones) and far faster
# than Flux diffusion. This is the recommended "opencv"-tier replacement when
# no GPU is available.
LAMA_MASK_DILATE_PX = 4  # Grow the OCR mask slightly so glyph edges/anti-aliasing are fully erased
LAMA_CONTEXT_PADDING = 32  # Extra border of real pixels fed to LaMa for texture context
LAMA_PAD_MULTIPLE = 8  # LaMa's conv stack requires H/W divisible by 8


def _lama_pad_to_multiple(image_np: np.ndarray, multiple: int = LAMA_PAD_MULTIPLE):
    """Reflect-pad an HxWxC (or HxW) array so H and W are divisible by `multiple`."""
    h, w = image_np.shape[:2]
    pad_h = (multiple - h % multiple) % multiple
    pad_w = (multiple - w % multiple) % multiple
    if image_np.ndim == 3:
        padded = np.pad(image_np, ((0, pad_h), (0, pad_w), (0, 0)), mode="reflect")
    else:
        padded = np.pad(image_np, ((0, pad_h), (0, pad_w)), mode="reflect")
    return padded, h, w


def lama_inpaint(
    pil_image: "Image.Image",
    mask_np: np.ndarray,
    bbox: Optional[Tuple[int, int, int, int]] = None,
    dilate_px: int = LAMA_MASK_DILATE_PX,
    context_padding: int = LAMA_CONTEXT_PADDING,
    verbose: bool = False,
    use_large: bool = False,
) -> "Image.Image":
    """
    Texture-aware OSB/SFX text removal using the LaMa (Large Mask Inpainting)
    model. LaMa is a fast, CPU-friendly CNN — no diffusion sampling loop like
    Flux — so it stays usable without a GPU while giving much cleaner results
    than classic cv2.inpaint on manga screentones/gradients/complex art.

    Falls back silently by raising; caller (finish_outside_text_work) is
    expected to catch and fall back to opencv_texture_inpaint on any failure.

    Args:
        pil_image: Full-page PIL image (RGB) to inpaint.
        mask_np: Boolean (or 0/255) array, same H/W as pil_image, True/255
            where the original text pixels are and should be erased.
        bbox: Optional (x1, y1, x2, y2) of the text region. When given, only a
            padded crop around it is run through LaMa (much faster on large
            pages); the result is pasted back using the mask.
        dilate_px: How many pixels to grow the mask by before inpainting.
        context_padding: Extra pixels of real artwork included around bbox.
        verbose: Enable debug logging.
        use_large: If True, use the additional "LaMa-Large" checkpoint
            (`load_lama_large`) instead of the default LaMa model. Same
            TorchScript calling convention, just a separate/optional model —
            the default LaMa model is untouched when this is False.

    Returns:
        A new PIL.Image with the masked text pixels erased and the
        surrounding artwork reconstructed. If nothing needs inpainting (empty
        mask) the original image is returned unchanged.
    """
    if pil_image is None:
        return pil_image

    img_w, img_h = pil_image.size
    mask_bool = mask_np.astype(bool)
    if not np.any(mask_bool):
        return pil_image

    if bbox is not None:
        x1, y1, x2, y2 = [int(v) for v in bbox]
        cx1 = max(0, x1 - context_padding)
        cy1 = max(0, y1 - context_padding)
        cx2 = min(img_w, x2 + context_padding)
        cy2 = min(img_h, y2 + context_padding)
    else:
        ys, xs = np.where(mask_bool)
        if ys.size == 0:
            return pil_image
        cx1 = max(0, int(xs.min()) - context_padding)
        cy1 = max(0, int(ys.min()) - context_padding)
        cx2 = min(img_w, int(xs.max()) + 1 + context_padding)
        cy2 = min(img_h, int(ys.max()) + 1 + context_padding)

    if cx2 <= cx1 or cy2 <= cy1:
        return pil_image

    crop_pil = pil_image.crop((cx1, cy1, cx2, cy2)).convert("RGB")
    crop_np = np.array(crop_pil)

    local_mask = mask_bool[cy1:cy2, cx1:cx2]
    if not np.any(local_mask):
        return pil_image

    local_mask_u8 = (local_mask.astype(np.uint8)) * 255
    if dilate_px > 0:
        kernel = cv2.getStructuringElement(
            cv2.MORPH_ELLIPSE, (dilate_px * 2 + 1, dilate_px * 2 + 1)
        )
        local_mask_u8 = cv2.dilate(local_mask_u8, kernel, iterations=1)

    model_manager = get_model_manager()
    model = (
        model_manager.load_lama_large(verbose=verbose)
        if use_large
        else model_manager.load_lama(verbose=verbose)
    )
    device = model_manager.device

    # Pad crop + mask so dimensions are divisible by 8 (LaMa conv requirement)
    padded_img, orig_h, orig_w = _lama_pad_to_multiple(crop_np)
    padded_mask, _, _ = _lama_pad_to_multiple(local_mask_u8)

    img_tensor = (
        torch.from_numpy(padded_img).float().permute(2, 0, 1).unsqueeze(0) / 255.0
    )
    mask_tensor = (
        torch.from_numpy(padded_mask).float().unsqueeze(0).unsqueeze(0) / 255.0
    )
    mask_tensor = (mask_tensor > 0.5).float()

    img_tensor = img_tensor.to(device)
    mask_tensor = mask_tensor.to(device)

    with torch.inference_mode():
        result_tensor = model(img_tensor, mask_tensor)

    result_np = result_tensor[0].permute(1, 2, 0).cpu().numpy()
    result_np = np.clip(result_np * 255, 0, 255).astype(np.uint8)
    # Crop back off the reflect-padding
    result_np = result_np[:orig_h, :orig_w]

    inpainted_crop_pil = Image.fromarray(result_np)

    result = pil_image.copy()
    # Feather the paste mask edge so the LaMa patch blends into surrounding
    # art instead of leaving a visible hard seam/outline.
    paste_mask_pil = Image.fromarray(local_mask_u8, mode="L").filter(
        ImageFilter.GaussianBlur(radius=1.2)
    )
    result.paste(inpainted_crop_pil, (cx1, cy1), mask=paste_mask_pil)

    log_message(
        f"LaMa inpaint applied to {cx2 - cx1}x{cy2 - cy1} region",
        verbose=verbose,
    )
    return result


def lama_or_opencv_inpaint(
    pil_image: "Image.Image",
    mask_np: np.ndarray,
    bbox: Optional[Tuple[int, int, int, int]] = None,
    verbose: bool = False,
    use_large: bool = False,
) -> "Image.Image":
    """
    Try LaMa first (better quality, CPU-friendly); if it fails for any reason
    (model download failure, OOM, runtime error, unsupported device, etc.)
    silently fall back to the classic OpenCV texture inpaint so the pipeline
    never hard-fails on this step.

    Args:
        use_large: Pass through to `lama_inpaint` to use the additional
            LaMa-Large checkpoint instead of the default LaMa model.
    """
    try:
        return lama_inpaint(
            pil_image, mask_np, bbox=bbox, verbose=verbose, use_large=use_large
        )
    except Exception as e:
        log_message(
            f"LaMa inpaint failed ({e}); falling back to OpenCV texture inpaint",
            always_print=True,
        )
        return opencv_texture_inpaint(
            pil_image, mask_np, method="telea", bbox=bbox, verbose=verbose
        )


def _prompt_value_to_cpu(value):
    if isinstance(value, torch.Tensor):
        return value.detach().to("cpu")
    if isinstance(value, tuple):
        return tuple(_prompt_value_to_cpu(item) for item in value)
    if isinstance(value, list):
        return [_prompt_value_to_cpu(item) for item in value]
    if isinstance(value, dict):
        return {key: _prompt_value_to_cpu(item) for key, item in value.items()}
    return value


def _prompt_value_to_device(value, device: torch.device):
    if isinstance(value, torch.Tensor):
        return value.to(device)
    if isinstance(value, tuple):
        return tuple(_prompt_value_to_device(item, device) for item in value)
    if isinstance(value, list):
        return [_prompt_value_to_device(item, device) for item in value]
    if isinstance(value, dict):
        return {
            key: _prompt_value_to_device(item, device) for key, item in value.items()
        }
    return value


def _pipeline_execution_device(pipeline, fallback: torch.device) -> torch.device:
    execution_device = getattr(pipeline, "_execution_device", None)
    if execution_device is None:
        return fallback
    return torch.device(execution_device)


def _encode_flux_prompt(pipeline, prompt: str, device: torch.device):
    try:
        encoded = pipeline.encode_prompt(prompt=prompt, prompt_2=None, device=device)
    except TypeError:
        encoded = pipeline.encode_prompt(prompt=prompt, device=device)

    if not isinstance(encoded, tuple) or len(encoded) < 2:
        raise RuntimeError("Flux prompt encoder returned an unexpected result.")

    return encoded[0], encoded[1]


def _flux_prompt_kwargs(
    prompt_embeds, pooled_prompt_embeds, include_pooled: bool = True
) -> Dict:
    kwargs = {"prompt_embeds": prompt_embeds}
    if include_pooled and pooled_prompt_embeds is not None:
        kwargs["pooled_prompt_embeds"] = pooled_prompt_embeds
    return kwargs


class FluxKontextInpainter:
    """Inpainter using Flux Kontext models for text removal."""

    def __init__(
        self,
        device: Optional[torch.device] = None,
        huggingface_token: str = "",
        num_inference_steps: int = 8,
        residual_diff_threshold: float = 0.15,
        backend: str = "nunchaku",
        low_vram: bool = False,
        sdcpp_cache_mode: str = "none",
        sdcpp_diffusion_quant: str = "",
        sdcpp_text_encoder_quant: str = "",
    ):
        """Initialize the Flux Kontext Inpaint class.

        Args:
            device: PyTorch device to use. Auto-detects if None.
            huggingface_token: HuggingFace token for model downloads (Nunchaku only).
            num_inference_steps: Number of denoising steps for inference.
            residual_diff_threshold: Residual diff threshold for Flux caching (Nunchaku only).
            backend: "nunchaku" (CUDA + Nunchaku + HF token), "sdnq", or "sdcpp".
            low_vram: If True, use sequential CPU offload for SDNQ.
            sdcpp_cache_mode: sd.cpp cache mode to use when backend is "sdcpp".
            sdcpp_diffusion_quant: Flux sd.cpp diffusion model quant.
            sdcpp_text_encoder_quant: Flux sd.cpp T5 text encoder quant.
        """
        self.DEVICE = device if device is not None else get_best_device()
        self.DTYPE = get_best_dtype(self.DEVICE)
        self.huggingface_token = huggingface_token
        self.num_inference_steps = num_inference_steps
        self.residual_diff_threshold = residual_diff_threshold
        self.backend = backend.lower()
        if self.backend not in ("nunchaku", "sdnq", "sdcpp"):
            raise ValueError(
                f"Invalid Kontext backend '{backend}'. "
                "Must be 'nunchaku', 'sdnq', or 'sdcpp'."
            )
        self.low_vram = low_vram
        self.sdcpp_cache_mode = sdcpp_cache_mode
        self.sdcpp_diffusion_quant = sdcpp_diffusion_quant or flux_sdcpp_quant_default(
            "flux_kontext", "diffusion_model"
        )
        self.sdcpp_text_encoder_quant = (
            sdcpp_text_encoder_quant or flux_sdcpp_text_encoder_default("flux_kontext")
        )
        self.manager = get_model_manager()
        self.cache = get_cache()

        # Preferred resolutions for optimal Flux performance
        self.PREFERED_KONTEXT_RESOLUTIONS = [
            (672, 1568),
            (688, 1504),
            (720, 1456),
            (752, 1392),
            (800, 1328),
            (832, 1248),
            (880, 1184),
            (944, 1104),
            (1024, 1024),
            (1104, 944),
            (1184, 880),
            (1248, 832),
            (1328, 800),
            (1392, 752),
            (1456, 720),
            (1504, 688),
            (1568, 672),
        ]

        self.pipeline = None
        self.transformer = None
        self.text_encoder_2 = None
        self.sdcpp_assets = None
        self._prompt_embeds_cpu = None
        self._pooled_prompt_embeds_cpu = None

        # Fixed parameters optimized for text removal
        self.guidance_scale = FLUX_GUIDANCE_SCALE
        self.prompt = "Remove all text."
        self.context_padding_ratio = CONTEXT_PADDING_RATIO
        self.max_context_padding = MAX_CONTEXT_PADDING

    def load_models(self):
        """Load Flux Kontext models via model manager."""
        if self.pipeline is not None:
            return

        if self.huggingface_token:
            self.manager.set_flux_hf_token(self.huggingface_token)

        if self.backend == "sdnq":
            # SDNQ: cross-platform, no token required
            self.pipeline = self.manager.load_flux_kontext_sdnq(
                low_vram=self.low_vram,
                verbose=True,
            )
            # SDNQ uses CPU offload, no separate transformer/text_encoder management
            self.transformer = None
            self.text_encoder_2 = None
        elif self.backend == "sdcpp":
            self.sdcpp_assets = self.manager.ensure_flux_sdcpp_server(
                "flux_kontext",
                cache_mode=self.sdcpp_cache_mode,
                diffusion_quant=self.sdcpp_diffusion_quant,
                text_encoder_quant=self.sdcpp_text_encoder_quant,
                num_inference_steps=self.num_inference_steps,
                verbose=True,
            )
            self.pipeline = self.sdcpp_assets
            self.transformer = None
            self.text_encoder_2 = None
        else:
            # Nunchaku: CUDA-only, requires token
            self.manager.set_flux_residual_diff_threshold(self.residual_diff_threshold)

            self.transformer, self.text_encoder_2, self.pipeline = (
                self.manager.load_flux_models()
            )

    def unload_models(self):
        """Unload Flux.1 Kontext models via model manager to free up memory."""
        self.pipeline = None
        self.transformer = None
        self.text_encoder_2 = None
        self.sdcpp_assets = None
        self._prompt_embeds_cpu = None
        self._pooled_prompt_embeds_cpu = None

        if self.backend == "sdnq":
            self.manager.unload_flux_kontext_sdnq_models()
        elif self.backend == "nunchaku":
            self.manager.unload_flux_kontext_models()
        elif self.backend == "sdcpp":
            self.manager.shutdown_sdcpp_server("flux_kontext")

    def _get_prompt_embeddings(self, device: torch.device, verbose: bool = False):
        if self._prompt_embeds_cpu is None:
            log_message("  - Encoding Flux prompt embeddings", verbose=verbose)
            prompt_embeds, pooled_prompt_embeds = _encode_flux_prompt(
                self.pipeline, self.prompt, device
            )
            self._prompt_embeds_cpu = _prompt_value_to_cpu(prompt_embeds)
            self._pooled_prompt_embeds_cpu = _prompt_value_to_cpu(pooled_prompt_embeds)
        else:
            log_message("  - Reusing Flux prompt embeddings", verbose=verbose)

        return (
            _prompt_value_to_device(self._prompt_embeds_cpu, device),
            _prompt_value_to_device(self._pooled_prompt_embeds_cpu, device),
        )

    def _run_sdcpp_inference(
        self,
        image_pil: Image.Image,
        width: int,
        height: int,
        seed: int,
        verbose: bool = False,
    ) -> Image.Image:
        if self.sdcpp_assets is None:
            raise ModelError("Flux.1 Kontext sd.cpp server is not loaded.")

        payload = {
            "prompt": self.prompt,
            "negative_prompt": "",
            "width": int(width),
            "height": int(height),
            "seed": int(seed),
            "batch_count": 1,
            "ref_images": [pil_to_base64_png(image_pil)],
            "sample_params": {
                "sample_method": "euler",
                "sample_steps": int(self.num_inference_steps),
                "guidance": {
                    "txt_cfg": 1.0,
                    "img_cfg": 1.0,
                    "distilled_guidance": float(self.guidance_scale),
                },
            },
            "output_format": "png",
            "output_compression": 100,
        }
        return run_image_job(
            self.sdcpp_assets, payload, verbose=verbose, timeout_sec=900
        )

    def convert_mask_to_tensor(self, mask_np):
        """Convert a numpy mask to the tensor format expected by the pipeline.

        Args:
            mask_np: Numpy mask array (H, W) with True/False values

        Returns:
            torch.Tensor: Mask tensor in CHW format (1.0 for areas to keep, 0.0 for areas to inpaint)
        """
        # Invert mask: True = inpaint (0.0), False = keep (1.0)
        mask_float = mask_np.astype(np.float32)
        mask_inverted = 1.0 - mask_float
        mask_tensor = torch.from_numpy(mask_inverted).unsqueeze(0)

        return mask_tensor

    def flux_kontext_image_scale(self, image_pil):
        """Find the closest preferred resolution and resize the image.

        Args:
            image_pil (PIL.Image): Input image to scale

        Returns:
            PIL.Image: Scaled image at the closest preferred resolution
        """
        w_in, h_in = image_pil.size
        if w_in == 0 or h_in == 0:
            return image_pil

        ar = w_in / h_in
        # Find resolution with minimum aspect ratio difference
        _, w_opt, h_opt = min(
            (abs(ar - w / h), w, h) for (w, h) in self.PREFERED_KONTEXT_RESOLUTIONS
        )

        log_message(
            f"  - Original image size: {w_in}x{h_in} (AR: {ar:.2f})", always_print=True
        )
        log_message(
            f"  - Scaling to nearest preferred resolution: {w_opt}x{h_opt}",
            always_print=True,
        )

        if (w_in, h_in) == (w_opt, h_opt):
            return image_pil

        # Use LANCZOS for high-quality downscaling
        image_scaled = image_pil.resize((w_opt, h_opt), Image.Resampling.LANCZOS)

        return image_scaled

    def compute_mask_bbox_aspect_ratio(
        self,
        mask_chw,
        padding,
        blur_radius,
        target_ar=None,
        transpose=False,
        preferred_resolutions=None,
        verbose=False,
    ):
        """Compute an optimized bounding box for the mask with aspect ratio adjustment.

        Args:
            mask_chw (torch.Tensor): Input mask tensor in CHW format
            padding (int): Padding around the mask bounding box
            blur_radius (int): Radius for edge blur effect
            target_ar (float, optional): Target aspect ratio
            transpose (bool): Whether to transpose the aspect ratio logic
            preferred_resolutions (list, optional): List of preferred resolutions
            verbose (bool): Whether to print verbose output

        Returns:
            tuple: (mask_for_composite, x, y, width, height)
        """
        if mask_chw.dim() == 4:
            mask = mask_chw[0, 0]
        else:
            mask = mask_chw[0]

        H, W = mask.shape[0], mask.shape[1]
        hard = mask.clone().unsqueeze(0)
        if blur_radius > 0:
            # Create smooth falloff at mask edges for better blending
            m_bool = hard[0].cpu().to(torch.float32).numpy().astype(bool)
            d_out = distance_transform_edt(~m_bool)
            d_in = distance_transform_edt(m_bool)
            alpha = np.zeros_like(d_out, np.float32)
            alpha[d_in > 0] = 1.0
            ramp = np.clip(1.0 - (d_out / blur_radius), 0.0, 1.0)
            alpha[d_out > 0] = ramp[d_out > 0]
            mask_blur_full = torch.from_numpy(alpha)[None, ...].to(hard.device)
        else:
            mask_blur_full = hard.clone()

        ys, xs = torch.where(hard[0] > 0)
        if len(ys) == 0:
            return (
                torch.zeros((1, H, W), device=mask_chw.device, dtype=mask_chw.dtype),
                0,
                0,
                W,
                H,
            )

        x1 = max(0, int(xs.min()) - padding)
        x2 = min(W, int(xs.max()) + 1 + padding)
        y1 = max(0, int(ys.min()) - padding)
        y2 = min(H, int(ys.max()) + 1 + padding)
        w0 = x2 - x1
        h0 = y2 - y1

        if preferred_resolutions:
            if h0 == 0:
                initial_ar = W / H
            else:
                initial_ar = w0 / h0
            log_message(
                f"  - Initial mask bounding box AR: {initial_ar:.2f}",
                verbose=verbose,
            )

            # Snap to closest preferred aspect ratio
            _, w_opt, h_opt = min(
                (abs(initial_ar - w / h), w, h) for (w, h) in preferred_resolutions
            )
            ar = w_opt / h_opt
            log_message(
                f"  - Snapping to closest preferred AR: {ar:.2f} ({w_opt}x{h_opt})",
                verbose=verbose,
            )
        else:
            ar = target_ar

        req_w = math.ceil(h0 * ar)
        req_h = math.floor(w0 / ar)

        new_x1, new_x2 = x1, x2
        new_y1, new_y2 = y1, y2

        flush_left = x1 == 0
        flush_right = x2 == W
        flush_top = y1 == 0
        flush_bot = y2 == H

        if not transpose:
            if req_w > w0:
                target_w = min(W, req_w)
                delta = target_w - w0
                if flush_right:
                    new_x1, new_x2 = W - target_w, W
                elif flush_left:
                    new_x1, new_x2 = 0, target_w
                else:
                    off = delta // 2
                    new_x1 = max(0, x1 - off)
                    new_x2 = new_x1 + target_w
                    if new_x2 > W:
                        new_x2 = W
                        new_x1 = W - target_w

            elif req_h > h0:
                target_h = min(H, req_h)
                delta = target_h - h0
                if flush_bot:
                    new_y1, new_y2 = H - target_h, H
                elif flush_top:
                    new_y1, new_y2 = 0, target_h
                else:
                    off = delta // 2
                    new_y1 = max(0, y1 - off)
                    new_y2 = new_y1 + target_h
                    if new_y2 > H:
                        new_y2 = H
                        new_y1 = H - target_h

        else:  # Transpose logic
            if req_h > h0:
                target_h = min(H, req_h)
                delta = target_h - h0
                if flush_bot:
                    new_y1, new_y2 = H - target_h, H
                elif flush_top:
                    new_y1, new_y2 = 0, target_h
                else:
                    off = delta // 2
                    new_y1 = max(0, y1 - off)
                    new_y2 = new_y1 + target_h
                    if new_y2 > H:
                        new_y2 = H
                        new_y1 = H - target_h

            elif req_w > w0:
                target_w = min(W, req_w)
                delta = target_w - w0
                if flush_right:
                    new_x1, new_x2 = W - target_w, W
                elif flush_left:
                    new_x1, new_x2 = 0, target_w
                else:
                    off = delta // 2
                    new_x1 = max(0, x1 - off)
                    new_x2 = new_x1 + target_w
                    if new_x2 > W:
                        new_x2 = W
                        new_x1 = W - target_w

        final_w = new_x2 - new_x1
        final_h = new_y2 - new_y1

        # Return cropped mask for compositing
        mask_for_composite = mask_blur_full[:, new_y1:new_y2, new_x1:new_x2]

        return (
            mask_for_composite.to(mask_chw.device, dtype=mask_chw.dtype),
            int(new_x1),
            int(new_y1),
            int(final_w),
            int(final_h),
        )

    def image_alpha_fix(self, destination, source):
        """Ensure destination and source tensors have compatible channel dimensions.

        Args:
            destination (torch.Tensor): Destination tensor
            source (torch.Tensor): Source tensor

        Returns:
            tuple: (destination, source) with compatible dimensions
        """
        dest_channels = destination.shape[-1]
        source_channels = source.shape[-1]

        if dest_channels == source_channels:
            return destination, source

        if dest_channels > source_channels:
            # Pad source to match destination's channel count
            padding = torch.ones(
                (*source.shape[:-1], dest_channels - source_channels),
                device=source.device,
                dtype=source.dtype,
            )
            source = torch.cat([source, padding], dim=-1)
        else:  # source_channels > dest_channels
            # Truncate source to match destination's channel count
            source = source[..., :dest_channels]

        return destination, source

    def repeat_to_batch_size(self, tensor, batch_size):
        """Adjust tensor batch size by repeating or truncating as needed.

        Args:
            tensor (torch.Tensor): Input tensor
            batch_size (int): Target batch size

        Returns:
            torch.Tensor: Tensor with the specified batch size
        """
        if tensor.shape[0] > batch_size:
            return tensor[:batch_size]
        elif tensor.shape[0] < batch_size:
            return tensor.repeat(batch_size, 1, 1, 1)
        return tensor

    def composite(
        self, destination, source, x, y, mask=None, multiplier=1, resize_source=False
    ):
        """Composite source image onto destination at specified coordinates.

        Args:
            destination (torch.Tensor): Destination image tensor
            source (torch.Tensor): Source image tensor
            x (int): X coordinate for placement
            y (int): Y coordinate for placement
            mask (torch.Tensor, optional): Alpha mask for blending
            multiplier (int): Coordinate multiplier
            resize_source (bool): Whether to resize source to match destination

        Returns:
            torch.Tensor: Composited image tensor
        """
        source = source.to(destination.device)
        if resize_source:
            source = torch.nn.functional.interpolate(
                source,
                size=(destination.shape[2], destination.shape[3]),
                mode="bilinear",
            )

        source = self.repeat_to_batch_size(source, destination.shape[0])

        x = max(
            -source.shape[3] * multiplier, min(x, destination.shape[3] * multiplier)
        )
        y = max(
            -source.shape[2] * multiplier, min(y, destination.shape[2] * multiplier)
        )

        left, top = (x // multiplier, y // multiplier)

        if mask is None:
            mask = torch.ones_like(source)
        else:
            mask = mask.to(destination.device, copy=True)
            mask = torch.nn.functional.interpolate(
                mask.reshape((-1, 1, mask.shape[-2], mask.shape[-1])),
                size=(source.shape[2], source.shape[3]),
                mode="bilinear",
            )
            mask = self.repeat_to_batch_size(mask, source.shape[0])

        visible_width = max(0, min(source.shape[3], destination.shape[3] - left))
        visible_height = max(0, min(source.shape[2], destination.shape[2] - top))

        if visible_width == 0 or visible_height == 0:
            return destination

        source_portion = source[:, :, :visible_height, :visible_width]
        mask_portion = mask[:, :, :visible_height, :visible_width]
        inverse_mask_portion = torch.ones_like(mask_portion) - mask_portion

        destination_portion = destination[
            :, :, top : top + visible_height, left : left + visible_width
        ]
        # Alpha blend source and destination using mask
        blended_portion = (source_portion * mask_portion) + (
            destination_portion * inverse_mask_portion
        )
        destination[:, :, top : top + visible_height, left : left + visible_width] = (
            blended_portion
        )

        return destination

    def image_composite_masked(
        self, destination, source, x, y, resize_source, mask=None
    ):
        """Wrapper function that handles channel dimension compatibility.

        Args:
            destination (torch.Tensor): Destination image tensor
            source (torch.Tensor): Source image tensor
            x (int): X coordinate for placement
            y (int): Y coordinate for placement
            resize_source (bool): Whether to resize source to match destination
            mask (torch.Tensor, optional): Alpha mask for blending

        Returns:
            torch.Tensor: Composited image tensor
        """
        destination, source = self.image_alpha_fix(destination, source)
        destination = destination.clone().movedim(-1, 1)
        output = self.composite(
            destination, source.movedim(-1, 1), x, y, mask, 1, resize_source
        ).movedim(1, -1)
        return output

    def inpaint_mask(
        self,
        image_pil: Image.Image,
        mask_np: np.ndarray,
        seed: int = 1,
        verbose: bool = False,
        ocr_params: Optional[Dict] = None,
        strict_mask_clipping: bool = False,
        composite_clip_bbox: Optional[Tuple[int, int, int, int]] = None,
    ) -> Image.Image:
        """Inpaint a specific mask region in the image.

        Args:
            image_pil: PIL Image to inpaint
            mask_np: Numpy mask array (H, W) with True for areas to inpaint
            seed: Random seed for inference
            verbose: Whether to print verbose output
            ocr_params: Optional OCR parameters dict for cache key generation
            strict_mask_clipping: When True, ensure compositing is limited to the
                original mask extent (no bleed from padding/blur)
            composite_clip_bbox: Optional (x1, y1, x2, y2) bbox to clip the final
                composite mask to, in original image coordinates.

        Returns:
            PIL.Image: The inpainted image
        """
        mask_np = np.asarray(mask_np)
        if mask_np.dtype != bool:
            mask_np = mask_np.astype(bool)

        if not np.any(mask_np):
            return image_pil

        log_message(
            "  - Computing optimized mask bounding box with blur and aspect ratio...",
            verbose=verbose,
        )

        ys, xs = np.where(mask_np)
        if len(ys) == 0 or len(xs) == 0:
            return image_pil

        x_min, x_max = int(xs.min()), int(xs.max())
        y_min, y_max = int(ys.min()), int(ys.max())

        bbox_width = x_max - x_min
        bbox_height = y_max - y_min

        padding_pixels = int(max(bbox_width, bbox_height) * self.context_padding_ratio)
        padding = min(padding_pixels, self.max_context_padding)
        log_message(
            f"  - Proportional context padding: {padding_pixels}px, capped to: {padding}px",
            verbose=verbose,
        )

        blur_radius = int(max(bbox_width, bbox_height) * BLUR_SCALE_FACTOR)
        blur_radius = max(
            MIN_BLUR_RADIUS, min(blur_radius, MAX_BLUR_RADIUS)
        )  # clamp between MIN and MAX
        log_message(f"  - Dynamic blur radius set to: {blur_radius}", verbose=verbose)

        mask_tensor = (
            torch.from_numpy(mask_np.astype(np.float32)).unsqueeze(0).unsqueeze(0)
        )

        mask_for_composite, x, y, width, height = self.compute_mask_bbox_aspect_ratio(
            mask_chw=mask_tensor,
            padding=padding,
            blur_radius=blur_radius,
            preferred_resolutions=self.PREFERED_KONTEXT_RESOLUTIONS,
            transpose=False,
            verbose=verbose,
        )

        # Quantize bbox to improve cache stability against minor detection jitter
        quant = 2
        img_h, img_w = mask_np.shape
        qx1 = max(0, min(img_w, int(round(x / quant) * quant)))
        qy1 = max(0, min(img_h, int(round(y / quant) * quant)))
        qx2 = max(qx1 + 1, min(img_w, int(round((x + width) / quant) * quant)))
        qy2 = max(qy1 + 1, min(img_h, int(round((y + height) / quant) * quant)))
        qwidth = max(1, qx2 - qx1)
        qheight = max(1, qy2 - qy1)

        # Adjust mask_for_composite to the quantized bbox via pad/crop
        dx_left = x - qx1
        dy_top = y - qy1
        dx_right = (qx1 + qwidth) - (x + width)
        dy_bottom = (qy1 + qheight) - (y + height)

        if dx_left > 0 or dx_right > 0 or dy_top > 0 or dy_bottom > 0:
            pad_l = max(dx_left, 0)
            pad_r = max(dx_right, 0)
            pad_t = max(dy_top, 0)
            pad_b = max(dy_bottom, 0)
            mask_for_composite = torch.nn.functional.pad(
                mask_for_composite, (pad_l, pad_r, pad_t, pad_b)
            )

        if dx_left < 0:
            mask_for_composite = mask_for_composite[:, :, -dx_left:]
        if dy_top < 0:
            mask_for_composite = mask_for_composite[:, -dy_top:, :]
        if mask_for_composite.shape[-1] > qwidth:
            mask_for_composite = mask_for_composite[:, :, :qwidth]
        if mask_for_composite.shape[-2] > qheight:
            mask_for_composite = mask_for_composite[:, :qheight, :]

        x, y, width, height = qx1, qy1, qwidth, qheight

        if strict_mask_clipping:
            original_mask_crop = mask_tensor[0, 0, y : y + height, x : x + width]
            mask_for_composite = mask_for_composite * original_mask_crop

        if composite_clip_bbox is not None:
            clip_x1, clip_y1, clip_x2, clip_y2 = composite_clip_bbox

            img_h, img_w = mask_np.shape
            clip_x1 = max(0, min(img_w, clip_x1))
            clip_x2 = max(0, min(img_w, clip_x2))
            clip_y1 = max(0, min(img_h, clip_y1))
            clip_y2 = max(0, min(img_h, clip_y2))

            start_x = max(0, clip_x1 - x)
            end_x = min(width, clip_x2 - x)
            start_y = max(0, clip_y1 - y)
            end_y = min(height, clip_y2 - y)

            if end_x <= start_x or end_y <= start_y:
                mask_for_composite = torch.zeros_like(mask_for_composite)
            else:
                clipped_mask = torch.zeros_like(mask_for_composite)
                clipped_mask[:, start_y:end_y, start_x:end_x] = mask_for_composite[
                    :, start_y:end_y, start_x:end_x
                ]
                mask_for_composite = clipped_mask

        log_message(
            f"  - Optimized bbox found at ({x}, {y}) with size {width}x{height}",
            verbose=verbose,
        )

        image_cropped_pil = image_pil.crop((x, y, x + width, y + height))
        mask_crop_np = mask_np[y : y + height, x : x + width]

        cache_params = {
            "bbox": (x, y, width, height),
            "padding": padding,
            "blur": blur_radius,
            "backend": self.backend,
        }
        if self.backend == "sdcpp":
            cache_params["sdcpp_cache"] = self.sdcpp_cache_mode
            cache_params["sdcpp_diffusion_quant"] = self.sdcpp_diffusion_quant
            cache_params["sdcpp_text_encoder_quant"] = self.sdcpp_text_encoder_quant
        if strict_mask_clipping:
            cache_params["strict_clip"] = True
        if composite_clip_bbox is not None:
            cache_params["clip_bbox"] = tuple(composite_clip_bbox)
        if ocr_params:
            cache_params.update(ocr_params)

        cache_key = None
        cached_patch = None
        if self.cache.should_use_inpaint_cache(seed):
            # Downsample mask signature to reduce sensitivity to minor jitter
            if mask_crop_np.size > 0:
                sig_h = min(64, max(4, mask_crop_np.shape[0]))
                sig_w = min(64, max(4, mask_crop_np.shape[1]))
                mask_sig = (
                    torch.from_numpy(mask_crop_np.astype(np.float32))
                    .unsqueeze(0)
                    .unsqueeze(0)
                )
                mask_sig = torch.nn.functional.interpolate(
                    mask_sig, size=(sig_h, sig_w), mode="bilinear", align_corners=False
                )
                mask_sig_np = (mask_sig > 0.5).cpu().numpy().astype(np.uint8)[0, 0]
            else:
                mask_sig_np = mask_crop_np

            cache_key = self.cache.get_inpaint_cache_key(
                image_cropped_pil,
                mask_sig_np,
                seed,
                self.num_inference_steps,
                self.residual_diff_threshold,
                self.guidance_scale,
                self.prompt,
                cache_params,
            )
            cached_patch = self.cache.get_inpainted_image(cache_key)
            if cached_patch is not None:
                log_message("  - Using cached inpainting patch", verbose=verbose)

        patch_pil = cached_patch

        if patch_pil is None:
            image_scaled_for_inference_pil = self.flux_kontext_image_scale(
                image_cropped_pil
            )
            inference_width, inference_height = image_scaled_for_inference_pil.size

            if image_scaled_for_inference_pil.mode == "RGBA":
                image_scaled_for_inference_pil = image_scaled_for_inference_pil.convert(
                    "RGB"
                )

            log_message("  - Running inference...", verbose=verbose)

            required_area = inference_width * inference_height

            # CPU offload moves weights between devices; serialize access across threads
            with self.manager.flux_inference_lock:
                self.load_models()

                if self.pipeline is None:
                    log_message(
                        "Warning: Flux Kontext pipeline not available. Skipping inpainting.",
                        always_print=True,
                    )
                    return image_pil

                if self.backend == "sdcpp":
                    generated_patch_pil = self._run_sdcpp_inference(
                        image_scaled_for_inference_pil,
                        inference_width,
                        inference_height,
                        seed,
                        verbose=verbose,
                    )
                elif self.backend == "sdnq":
                    with torch.inference_mode():
                        gen_device = "cpu" if self.low_vram else self.DEVICE
                        gen = torch.Generator(device=gen_device).manual_seed(seed)
                        prompt_device = _pipeline_execution_device(
                            self.pipeline, self.DEVICE
                        )
                        prompt_embeds, pooled_prompt_embeds = (
                            self._get_prompt_embeddings(prompt_device, verbose=verbose)
                        )
                        out = self.pipeline(
                            **_flux_prompt_kwargs(prompt_embeds, pooled_prompt_embeds),
                            image=image_scaled_for_inference_pil,
                            width=inference_width,
                            height=inference_height,
                            num_inference_steps=self.num_inference_steps,
                            guidance_scale=self.guidance_scale,
                            generator=gen,
                            output_type="pt",
                            max_area=required_area,
                        )
                        img = out.images[0]
                        torch.nan_to_num_(img, nan=0.0, posinf=1.0, neginf=0.0)
                        img.clamp_(0, 1)
                        generated_patch_pil = Image.fromarray(
                            (
                                img.mul(255)
                                .round()
                                .to(torch.uint8)
                                .permute(1, 2, 0)
                                .cpu()
                                .numpy()
                            )
                        )
                else:
                    should_encode_prompt = self._prompt_embeds_cpu is None
                    if should_encode_prompt:
                        self.pipeline.text_encoder_2.to(self.DEVICE)

                    prompt_embeds, pooled_prompt_embeds = self._get_prompt_embeddings(
                        self.DEVICE, verbose=verbose
                    )

                    if should_encode_prompt:
                        self.pipeline.text_encoder_2.to("cpu")
                        empty_cache(self.DEVICE)

                    self.pipeline.transformer.to(self.DEVICE)

                    with torch.inference_mode():
                        gen = torch.Generator(device=self.DEVICE).manual_seed(seed)
                        out = self.pipeline(
                            **_flux_prompt_kwargs(prompt_embeds, pooled_prompt_embeds),
                            image=image_scaled_for_inference_pil,
                            width=inference_width,
                            height=inference_height,
                            num_inference_steps=self.num_inference_steps,
                            guidance_scale=self.guidance_scale,
                            generator=gen,
                            output_type="pt",
                            max_area=required_area,
                        )
                        img = out.images[0]
                        torch.nan_to_num_(img, nan=0.0, posinf=1.0, neginf=0.0)
                        img.clamp_(0, 1)
                        generated_patch_pil = Image.fromarray(
                            (
                                img.mul(255)
                                .round()
                                .to(torch.uint8)
                                .permute(1, 2, 0)
                                .cpu()
                                .numpy()
                            )
                        )

                    self.pipeline.transformer.to("cpu")
                    empty_cache(self.DEVICE)

            patch_pil = generated_patch_pil.resize(
                (width, height), Image.Resampling.LANCZOS
            )

        dest_tensor = torch.from_numpy(
            np.asarray(image_pil, dtype=np.float32) / 255.0
        ).unsqueeze(0)
        src_tensor = torch.from_numpy(
            np.asarray(patch_pil, dtype=np.float32) / 255.0
        ).unsqueeze(0)

        composited_tensor = self.image_composite_masked(
            destination=dest_tensor,
            source=src_tensor,
            x=x,
            y=y,
            resize_source=False,
            mask=mask_for_composite,
        )

        composited_pil = Image.fromarray(
            (composited_tensor[0].cpu().numpy() * 255).astype("uint8")
        )

        if (
            self.cache.should_use_inpaint_cache(seed)
            and cache_key is not None
            and cached_patch is None
        ):
            self.cache.set_inpainted_image(cache_key, patch_pil)

        return composited_pil


class SDXLInpainter:
    """Inpainter using the SDXL 1.0 Inpainting model
    (diffusers/stable-diffusion-xl-1.0-inpainting-0.1) for OSB text removal
    and art regeneration.

    Positioned between LaMa and Flux: noticeably better art regen quality
    than LaMa (real diffusion sampling vs. a CNN texture-fill), while being
    lighter/faster than Flux Kontext/Klein since SDXL is a much smaller
    latent-diffusion model with a mature, highly-optimized diffusers path
    (DPM++ Karras scheduler, SDPA/xformers attention, VAE slicing/tiling).
    """

    # SDXL's native resolution; inpainting quality degrades outside this
    # neighborhood, so crops are scaled towards it before inference.
    NATIVE_RESOLUTION = 1024
    MIN_RESOLUTION = 256
    MAX_RESOLUTION = 1536  # cap to keep inference fast on large panels
    RESOLUTION_MULTIPLE = 8  # SDXL VAE downsample factor
    SDXL_PADDING_MULTIPLIER = 1.5

    SDXL_PROMPT = (
        "manga panel artwork, hand-drawn black and white line art, "
        "screentone shading, seamless continuation of the surrounding "
        "background and character art, sharp clean linework, no text, "
        "no letters, no watermark, high detail"
    )
    SDXL_NEGATIVE_PROMPT = (
        "text, letters, watermark, signature, blurry, low quality, "
        "jpeg artifacts, distorted anatomy, extra lines, noise, color, "
        "smudge, out of frame"
    )

    def __init__(
        self,
        device: Optional[torch.device] = None,
        num_inference_steps: int = 9,
        guidance_scale: float = 6.5,
        strength: float = 0.99,
        low_vram: bool = False,
        luminance_correction: bool = True,
        upscale_small_crops: bool = True,
        verbose: bool = False,
    ):
        """Initialize the SDXL Inpainter.

        Args:
            device: PyTorch device to use. Auto-detects if None.
            num_inference_steps: Denoising steps. Default 9 (8-10 range) w/
                DPM++2M Karras — fast, tuned for speed. Below ~8, detail/
                sharpness starts dropping off noticeably; going up towards
                15-20 buys back some fine-detail quality if speed allows.
            guidance_scale: Classifier-free guidance strength. Lowered to
                6.5 (from the model card's 7-8) to pair with the low step
                count — high CFG + few steps tends to oversaturate/artifact,
                so this keeps low-step output clean.
            strength: Denoising strength within the mask (0.99 = near-full
                regeneration, matching Flux's "regenerate the art" behavior).
            low_vram: If True, use model CPU offload (slower, lower VRAM).
            luminance_correction: If True, match patch luminance to
                surrounding context (same technique as the Flux inpainters).
            upscale_small_crops: If True, scale small crops up towards
                SDXL's native 1024px before inference for sharper detail.
            verbose: Whether to print verbose logging.
        """
        self.num_inference_steps = num_inference_steps
        self.guidance_scale = guidance_scale
        self.strength = strength
        self.low_vram = low_vram
        self.luminance_correction = luminance_correction
        self.upscale_small_crops = upscale_small_crops
        self.verbose = verbose

        self.DEVICE = device if device is not None else get_best_device()
        self.manager = get_model_manager()
        self.cache = get_cache()
        self.pipeline = None

    def load_models(self):
        """Load the SDXL inpainting pipeline via the model manager."""
        if self.pipeline is not None:
            return
        self.pipeline = self.manager.load_sdxl_inpaint(
            low_vram=self.low_vram, verbose=self.verbose
        )

    def unload_models(self):
        """Unload the SDXL inpainting pipeline to free up memory."""
        self.pipeline = None
        self.manager.unload_sdxl_inpaint(verbose=self.verbose)

    def _quantize_dimension(self, dim: int) -> int:
        dim = max(self.MIN_RESOLUTION, min(self.MAX_RESOLUTION, dim))
        return (dim // self.RESOLUTION_MULTIPLE) * self.RESOLUTION_MULTIPLE

    def _expand_bounds_to_min_size(
        self,
        x1: int,
        y1: int,
        x2: int,
        y2: int,
        img_w: int,
        img_h: int,
    ) -> Tuple[int, int, int, int]:
        target_w = min(self.MIN_RESOLUTION, img_w)
        target_h = min(self.MIN_RESOLUTION, img_h)

        width = x2 - x1
        if width < target_w:
            extra = target_w - width
            x1 = max(0, x1 - extra // 2)
            x2 = min(img_w, x2 + extra - extra // 2)
            if x2 - x1 < target_w:
                if x1 == 0:
                    x2 = min(img_w, target_w)
                else:
                    x1 = max(0, img_w - target_w)

        height = y2 - y1
        if height < target_h:
            extra = target_h - height
            y1 = max(0, y1 - extra // 2)
            y2 = min(img_h, y2 + extra - extra // 2)
            if y2 - y1 < target_h:
                if y1 == 0:
                    y2 = min(img_h, target_h)
                else:
                    y1 = max(0, img_h - target_h)

        return x1, y1, x2, y2

    def _prepare_image_for_inference(
        self, image_pil: Image.Image, verbose: bool = False
    ) -> Tuple[Image.Image, int, int]:
        """Scale the crop towards SDXL's native ~1024px resolution."""
        orig_w, orig_h = image_pil.size
        current_pixels = orig_w * orig_h

        if current_pixels <= 0:
            scale = 1.0
        elif self.upscale_small_crops:
            target_pixels = self.NATIVE_RESOLUTION * self.NATIVE_RESOLUTION
            scale = math.sqrt(target_pixels / current_pixels)
        else:
            max_pixels = self.MAX_RESOLUTION * self.MAX_RESOLUTION
            scale = (
                math.sqrt(max_pixels / current_pixels)
                if current_pixels > max_pixels
                else 1.0
            )

        new_w = self._quantize_dimension(int(orig_w * scale))
        new_h = self._quantize_dimension(int(orig_h * scale))

        if (new_w, new_h) != (orig_w, orig_h):
            log_message(
                f"  - Scaling {orig_w}x{orig_h} -> {new_w}x{new_h} (SDXL native res)",
                verbose=verbose,
            )
            image_pil = image_pil.resize((new_w, new_h), Image.Resampling.LANCZOS)

        return image_pil, orig_w, orig_h

    def _compute_luminance_stats(
        self, image_np: np.ndarray, mask_np: np.ndarray
    ) -> Tuple[float, float]:
        if not np.any(mask_np):
            return 127.5, 30.0
        lab = cv2.cvtColor(image_np, cv2.COLOR_RGB2LAB)
        l_values = lab[:, :, 0][mask_np].astype(np.float32)
        return float(np.mean(l_values)), float(np.std(l_values)) + 1e-6

    def _match_luminance(
        self,
        generated_pil: Image.Image,
        original_crop_pil: Image.Image,
        mask_crop_np: np.ndarray,
        verbose: bool = False,
    ) -> Image.Image:
        """Match luminance/chroma of the generated patch to surrounding
        context (same affine-correction approach used by the Flux inpainters,
        so results look consistent regardless of which OSB method is active)."""
        context_mask = ~mask_crop_np
        if not np.any(context_mask) or not np.any(mask_crop_np):
            return generated_pil

        original_np = np.asarray(original_crop_pil)
        generated_np = np.asarray(generated_pil).copy()

        orig_mean, orig_std = self._compute_luminance_stats(original_np, context_mask)
        gen_mean, gen_std = self._compute_luminance_stats(generated_np, context_mask)

        if abs(orig_mean - gen_mean) < 1.3 and abs(orig_std - gen_std) < 2.0:
            return generated_pil

        scale = max(0.5, min(2.0, orig_std / gen_std))

        log_message(
            f"  - Luminance correction: mean {gen_mean:.1f}->{orig_mean:.1f}, "
            f"std {gen_std:.1f}->{orig_std:.1f} (scale={scale:.2f})",
            verbose=verbose,
        )

        lab = cv2.cvtColor(generated_np, cv2.COLOR_RGB2LAB).astype(np.float32)
        l_masked = lab[:, :, 0][mask_crop_np]
        lab[:, :, 0][mask_crop_np] = np.clip(
            (l_masked - gen_mean) * scale + orig_mean, 0, 255
        )

        orig_lab = cv2.cvtColor(original_np, cv2.COLOR_RGB2LAB).astype(np.float32)
        for ch in (1, 2):
            orig_ch_mean = float(np.mean(orig_lab[:, :, ch][context_mask]))
            gen_ch_mean = float(np.mean(lab[:, :, ch][context_mask]))
            ch_shift = orig_ch_mean - gen_ch_mean
            if abs(ch_shift) > 1.0:
                lab[:, :, ch][mask_crop_np] = np.clip(
                    lab[:, :, ch][mask_crop_np] + ch_shift, 0, 255
                )

        corrected_np = cv2.cvtColor(lab.astype(np.uint8), cv2.COLOR_LAB2RGB)
        return Image.fromarray(corrected_np)

    def inpaint_mask(
        self,
        image_pil: Image.Image,
        mask_np: np.ndarray,
        seed: int = 1,
        verbose: bool = False,
        strict_mask_clipping: bool = False,
        composite_clip_bbox: Optional[Tuple[int, int, int, int]] = None,
        ocr_params: Optional[Dict] = None,
    ) -> Image.Image:
        """Inpaint a specific mask region in the image using SDXL Inpainting.

        Mirrors FluxKleinInpainter.inpaint_mask's contract (crop -> context
        padding -> inference -> feathered composite -> luminance match), so it
        drops into the same OSB pipeline dispatch without further changes.
        """
        mask_np = np.asarray(mask_np)
        if mask_np.dtype != bool:
            mask_np = mask_np.astype(bool)

        if not np.any(mask_np):
            return image_pil

        log_message("  - SDXL Inpainting...", verbose=verbose)

        ys, xs = np.where(mask_np)
        if len(ys) == 0 or len(xs) == 0:
            return image_pil

        x_min, x_max = int(xs.min()), int(xs.max())
        y_min, y_max = int(ys.min()), int(ys.max())
        bbox_width = x_max - x_min
        bbox_height = y_max - y_min

        padding_pixels = int(max(bbox_width, bbox_height) * CONTEXT_PADDING_RATIO)
        padding = int(
            min(padding_pixels, MAX_CONTEXT_PADDING) * self.SDXL_PADDING_MULTIPLIER
        )

        blur_radius = int(max(bbox_width, bbox_height) * BLUR_SCALE_FACTOR)
        blur_radius = max(MIN_BLUR_RADIUS, min(blur_radius, MAX_BLUR_RADIUS))

        img_h, img_w = mask_np.shape
        x1 = max(0, x_min - padding)
        y1 = max(0, y_min - padding)
        x2 = min(img_w, x_max + 1 + padding)
        y2 = min(img_h, y_max + 1 + padding)
        x1, y1, x2, y2 = self._expand_bounds_to_min_size(x1, y1, x2, y2, img_w, img_h)

        width = min(self._quantize_dimension(x2 - x1), img_w)
        height = min(self._quantize_dimension(y2 - y1), img_h)
        if x1 + width > img_w:
            x1 = max(0, img_w - width)
        if y1 + height > img_h:
            y1 = max(0, img_h - height)
        x2, y2 = x1 + width, y1 + height
        width, height = x2 - x1, y2 - y1

        if width <= 0 or height <= 0:
            log_message(
                f"  - Region has invalid size ({width}x{height}), skipping",
                verbose=verbose,
            )
            return image_pil

        log_message(
            f"  - Processing region at ({x1}, {y1}) size {width}x{height}",
            verbose=verbose,
        )

        image_cropped_pil = image_pil.crop((x1, y1, x2, y2))
        if image_cropped_pil.mode != "RGB":
            image_cropped_pil = image_cropped_pil.convert("RGB")
        mask_crop_np = mask_np[y1:y2, x1:x2]

        cache_params = {
            "bbox": (x1, y1, width, height),
            "padding": padding,
            "blur": blur_radius,
            "method": "sdxl",
            "steps": self.num_inference_steps,
            "guidance": self.guidance_scale,
            "strength": self.strength,
            "lum_corr": self.luminance_correction,
            "upscale_small": self.upscale_small_crops,
        }
        if strict_mask_clipping:
            cache_params["strict_clip"] = True
        if composite_clip_bbox is not None:
            cache_params["clip_bbox"] = tuple(composite_clip_bbox)
        if ocr_params:
            cache_params.update(ocr_params)

        cache_key = None
        cached_patch = None
        if self.cache.should_use_inpaint_cache(seed):
            cache_key = self.cache.get_inpaint_cache_key(
                image_cropped_pil,
                mask_crop_np.astype(np.uint8),
                seed,
                self.num_inference_steps,
                self.guidance_scale,
                self.SDXL_PROMPT,
                cache_params,
            )
            cached_patch = self.cache.get_inpainted_image(cache_key)
            if cached_patch is not None:
                log_message("  - Using cached inpainting patch", verbose=verbose)

        mask_float = mask_crop_np.astype(np.float32)
        if blur_radius > 0:
            d_out = distance_transform_edt(~mask_crop_np)
            d_in = distance_transform_edt(mask_crop_np)
            alpha = np.zeros_like(d_out, np.float32)
            alpha[d_in > 0] = 1.0
            ramp = np.clip(1.0 - (d_out / blur_radius), 0.0, 1.0)
            alpha[d_out > 0] = ramp[d_out > 0]
            mask_for_composite = torch.from_numpy(alpha)[None, ...]
        else:
            mask_for_composite = torch.from_numpy(mask_float)[None, ...]

        if strict_mask_clipping:
            original_mask_crop = torch.from_numpy(mask_crop_np.astype(np.float32))
            mask_for_composite = mask_for_composite * original_mask_crop

        if composite_clip_bbox is not None:
            clip_x1, clip_y1, clip_x2, clip_y2 = composite_clip_bbox
            clip_x1 = max(0, min(img_w, clip_x1))
            clip_x2 = max(0, min(img_w, clip_x2))
            clip_y1 = max(0, min(img_h, clip_y1))
            clip_y2 = max(0, min(img_h, clip_y2))
            start_x = max(0, clip_x1 - x1)
            end_x = min(width, clip_x2 - x1)
            start_y = max(0, clip_y1 - y1)
            end_y = min(height, clip_y2 - y1)
            if end_x <= start_x or end_y <= start_y:
                mask_for_composite = torch.zeros_like(mask_for_composite)
            else:
                clipped_mask = torch.zeros_like(mask_for_composite)
                clipped_mask[:, start_y:end_y, start_x:end_x] = mask_for_composite[
                    :, start_y:end_y, start_x:end_x
                ]
                mask_for_composite = clipped_mask

        patch_pil = cached_patch

        if patch_pil is None:
            inference_image, _, _ = self._prepare_image_for_inference(
                image_cropped_pil, verbose=verbose
            )
            inference_w, inference_h = inference_image.size

            # SDXL inpaint pipeline wants the mask at the same resolution as
            # the image, white (255) = region to regenerate.
            mask_img_pil = Image.fromarray(
                (mask_crop_np.astype(np.uint8) * 255)
            ).resize((inference_w, inference_h), Image.Resampling.NEAREST)

            log_message("  - Running inference...", verbose=verbose)

            with self.manager.flux_inference_lock:
                self.load_models()

                if self.pipeline is None:
                    log_message(
                        "Warning: SDXL Inpainting pipeline unavailable.",
                        always_print=True,
                    )
                    return image_pil

                gen = torch.Generator(device=self.DEVICE).manual_seed(seed)
                with torch.inference_mode():
                    out = self.pipeline(
                        prompt=self.SDXL_PROMPT,
                        negative_prompt=self.SDXL_NEGATIVE_PROMPT,
                        image=inference_image,
                        mask_image=mask_img_pil,
                        width=inference_w,
                        height=inference_h,
                        num_inference_steps=self.num_inference_steps,
                        guidance_scale=self.guidance_scale,
                        strength=self.strength,
                        generator=gen,
                    )
                    generated_patch_pil = out.images[0]

            if (inference_w, inference_h) != (width, height):
                patch_pil = generated_patch_pil.resize(
                    (width, height), Image.Resampling.LANCZOS
                )
            else:
                patch_pil = generated_patch_pil

            if self.luminance_correction:
                patch_pil = self._match_luminance(
                    generated_pil=patch_pil,
                    original_crop_pil=image_cropped_pil,
                    mask_crop_np=mask_crop_np,
                    verbose=verbose,
                )

        dest_tensor = torch.from_numpy(
            np.asarray(image_pil, dtype=np.float32) / 255.0
        ).unsqueeze(0)
        src_tensor = torch.from_numpy(
            np.asarray(patch_pil, dtype=np.float32) / 255.0
        ).unsqueeze(0)

        dest_channels = dest_tensor.shape[-1]
        src_channels = src_tensor.shape[-1]
        if dest_channels > src_channels:
            pad = torch.ones(
                (*src_tensor.shape[:-1], dest_channels - src_channels),
                device=src_tensor.device,
                dtype=src_tensor.dtype,
            )
            src_tensor = torch.cat([src_tensor, pad], dim=-1)
        elif src_channels > dest_channels:
            src_tensor = src_tensor[..., :dest_channels]

        dest_tensor = dest_tensor.movedim(-1, 1)
        src_tensor = src_tensor.movedim(-1, 1)

        mask_interp = torch.nn.functional.interpolate(
            mask_for_composite.reshape(
                (-1, 1, mask_for_composite.shape[-2], mask_for_composite.shape[-1])
            ),
            size=(src_tensor.shape[2], src_tensor.shape[3]),
            mode="bilinear",
        )

        composited = dest_tensor.clone()
        visible_h = min(src_tensor.shape[2], dest_tensor.shape[2] - y1)
        visible_w = min(src_tensor.shape[3], dest_tensor.shape[3] - x1)

        if visible_h > 0 and visible_w > 0:
            src_portion = src_tensor[:, :, :visible_h, :visible_w]
            mask_portion = mask_interp[:, :, :visible_h, :visible_w]
            dest_portion = composited[:, :, y1 : y1 + visible_h, x1 : x1 + visible_w]
            blended = src_portion * mask_portion + dest_portion * (1 - mask_portion)
            composited[:, :, y1 : y1 + visible_h, x1 : x1 + visible_w] = blended

        composited = composited.movedim(1, -1)
        composited_pil = Image.fromarray(
            (composited[0].cpu().numpy() * 255).astype("uint8")
        )

        if (
            self.cache.should_use_inpaint_cache(seed)
            and cache_key is not None
            and cached_patch is None
        ):
            self.cache.set_inpainted_image(cache_key, patch_pil)

        return composited_pil


class FluxKleinInpainter:
    """Inpainter using Flux.2 Klein models for text removal.

    Unlike FluxKontextInpainter, this works on CPU/ROCm/MPS without Nunchaku.
    Uses FP8 quantized models for reduced memory usage.
    """

    # Parameters for Klein models (distilled, optimized)
    KLEIN_MAX_STEPS = 12  # Max steps for Klein models
    KLEIN_DEFAULT_STEPS = 4  # Recommended default
    KLEIN_GUIDANCE_SCALE = 1.0  # Fixed CFG for Klein
    KLEIN_PROMPT = (
        "Remove all text. Preserve all character line art, screentones, panel borders, "
        "and background details exactly as they appear. Maintain the original "
        "contrast and shading, ensuring character expressions and environmental textures "
        "remain unchanged while leaving the text areas completely blank."
    )

    # Resolution constraints: 64x64 to 2048x2048, multiple of 16
    MIN_RESOLUTION = 64
    MAX_RESOLUTION = 2048
    RESOLUTION_MULTIPLE = 16
    MAX_INFERENCE_PIXELS = 4_000_000
    KLEIN_PADDING_MULTIPLIER = 2.0  # Double padding vs Kontext for more context

    def __init__(
        self,
        variant: str = "4b",
        device: Optional[torch.device] = None,
        huggingface_token: str = "",
        num_inference_steps: int = 4,
        low_vram: bool = False,
        luminance_correction: bool = True,
        upscale_small_crops: bool = True,
        backend: str = "sdnq",
        sdcpp_cache_mode: str = "none",
        sdcpp_diffusion_quant: str = "",
        sdcpp_text_encoder_quant: str = "",
        verbose: bool = False,
    ):
        """Initialize the Flux Klein Inpainter.

        Args:
            variant: Model variant - "9b" or "4b" (default: "4b")
            device: PyTorch device to use. Auto-detects if None.
            huggingface_token: HuggingFace token (required for 9B gated repo).
            num_inference_steps: Number of denoising steps (1-12, default: 4).
            low_vram: If True, use sequential CPU offload for SDNQ.
            luminance_correction: If True, match patch luminance to surrounding context.
            upscale_small_crops: If True, scale small crops to ~1MP before inference.
            backend: "sdnq" for Diffusers/SDNQ or "sdcpp" for stable-diffusion.cpp.
            sdcpp_cache_mode: sd.cpp cache mode to use when backend is "sdcpp".
            sdcpp_diffusion_quant: Flux sd.cpp diffusion model quant.
            sdcpp_text_encoder_quant: Flux sd.cpp Qwen text encoder quant.
            verbose: Whether to print verbose logging.
        """
        self.variant = variant.lower()
        if self.variant not in ("9b", "4b"):
            raise ValueError(f"Invalid variant '{variant}'. Must be '9b' or '4b'.")

        self.backend = backend.lower()
        if self.backend not in ("sdnq", "sdcpp"):
            raise ValueError(
                f"Invalid Klein backend '{backend}'. Must be 'sdnq' or 'sdcpp'."
            )

        self.num_inference_steps = num_inference_steps
        self.low_vram = low_vram
        self.luminance_correction = luminance_correction
        self.upscale_small_crops = upscale_small_crops
        self.sdcpp_cache_mode = sdcpp_cache_mode
        _model_key = f"flux_klein_{self.variant}"
        self.sdcpp_diffusion_quant = sdcpp_diffusion_quant or flux_sdcpp_quant_default(
            _model_key, "diffusion_model"
        )
        self.sdcpp_text_encoder_quant = (
            sdcpp_text_encoder_quant or flux_sdcpp_text_encoder_default(_model_key)
        )
        self.verbose = verbose

        self.DEVICE = device if device is not None else get_best_device()
        self.DTYPE = get_best_dtype(self.DEVICE)
        self.huggingface_token = huggingface_token
        self.manager = get_model_manager()
        self.cache = get_cache()
        self.pipeline = None
        self.sdcpp_assets = None
        self._prompt_embeds_cpu = None
        self._pooled_prompt_embeds_cpu = None

    def load_models(self):
        """Load Flux Klein models via model manager."""
        if self.pipeline is not None:
            return

        if self.huggingface_token:
            self.manager.set_flux_hf_token(self.huggingface_token)

        if self.backend == "sdcpp":
            self.sdcpp_assets = self.manager.ensure_flux_sdcpp_server(
                f"flux_klein_{self.variant}",
                cache_mode=self.sdcpp_cache_mode,
                diffusion_quant=self.sdcpp_diffusion_quant,
                text_encoder_quant=self.sdcpp_text_encoder_quant,
                num_inference_steps=self.num_inference_steps,
                verbose=self.verbose,
            )
            self.pipeline = self.sdcpp_assets
            return

        if self.variant == "9b":
            self.pipeline = self.manager.load_flux_klein_9b(
                low_vram=self.low_vram, verbose=self.verbose
            )
        else:
            self.pipeline = self.manager.load_flux_klein_4b(
                low_vram=self.low_vram, verbose=self.verbose
            )

    def unload_models(self):
        """Unload Flux.2 Klein models via model manager to free up memory."""
        self.pipeline = None
        self.sdcpp_assets = None
        self._prompt_embeds_cpu = None
        self._pooled_prompt_embeds_cpu = None
        if self.backend == "sdcpp":
            self.manager.shutdown_sdcpp_server(f"flux_klein_{self.variant}")
        else:
            self.manager.unload_flux_klein_models()

    def _get_prompt_embeddings(self, device: torch.device, verbose: bool = False):
        if self._prompt_embeds_cpu is None:
            log_message("  - Encoding Flux.2 Klein prompt embeddings", verbose=verbose)
            prompt_embeds, pooled_prompt_embeds = _encode_flux_prompt(
                self.pipeline, self.KLEIN_PROMPT, device
            )
            self._prompt_embeds_cpu = _prompt_value_to_cpu(prompt_embeds)
            self._pooled_prompt_embeds_cpu = _prompt_value_to_cpu(pooled_prompt_embeds)
        else:
            log_message("  - Reusing Flux.2 Klein prompt embeddings", verbose=verbose)

        return (
            _prompt_value_to_device(self._prompt_embeds_cpu, device),
            _prompt_value_to_device(self._pooled_prompt_embeds_cpu, device),
        )

    def _quantize_dimension(self, dim: int) -> int:
        """Quantize dimension to be a multiple of RESOLUTION_MULTIPLE within allowed range."""
        dim = max(self.MIN_RESOLUTION, min(self.MAX_RESOLUTION, dim))
        return (dim // self.RESOLUTION_MULTIPLE) * self.RESOLUTION_MULTIPLE

    def _expand_bounds_to_min_size(
        self,
        x1: int,
        y1: int,
        x2: int,
        y2: int,
        img_w: int,
        img_h: int,
    ) -> Tuple[int, int, int, int]:
        target_w = min(self.MIN_RESOLUTION, img_w)
        target_h = min(self.MIN_RESOLUTION, img_h)

        width = x2 - x1
        if width < target_w:
            extra = target_w - width
            x1 = max(0, x1 - extra // 2)
            x2 = min(img_w, x2 + extra - extra // 2)
            if x2 - x1 < target_w:
                if x1 == 0:
                    x2 = min(img_w, target_w)
                else:
                    x1 = max(0, img_w - target_w)

        height = y2 - y1
        if height < target_h:
            extra = target_h - height
            y1 = max(0, y1 - extra // 2)
            y2 = min(img_h, y2 + extra - extra // 2)
            if y2 - y1 < target_h:
                if y1 == 0:
                    y2 = min(img_h, target_h)
                else:
                    y1 = max(0, img_h - target_h)

        return x1, y1, x2, y2

    def _compute_luminance_stats(
        self, image_np: np.ndarray, mask_np: np.ndarray
    ) -> Tuple[float, float]:
        """Compute mean and std of luminance (LAB L channel) for masked pixels.

        Args:
            image_np: RGB image array (H, W, 3), uint8
            mask_np: Boolean mask where True = pixels to include

        Returns:
            (mean, std) of L channel values (0-255 scale, cv2 LAB)
        """
        if not np.any(mask_np):
            return 127.5, 30.0  # Neutral fallback

        lab = cv2.cvtColor(image_np, cv2.COLOR_RGB2LAB)
        l_values = lab[:, :, 0][mask_np].astype(np.float32)

        return float(np.mean(l_values)), float(np.std(l_values)) + 1e-6

    def _match_luminance(
        self,
        generated_pil: Image.Image,
        original_crop_pil: Image.Image,
        mask_crop_np: np.ndarray,
        verbose: bool = False,
    ) -> Image.Image:
        """Match luminance of generated patch to original context using affine correction.

        Uses all non-mask pixels in the crop as context (rather than only
        outside-bbox pixels), giving a more stable luminance reference.
        Applies an affine remap (mean + std matching) to preserve the
        generated patch's internal contrast while aligning brightness.
        Correction is applied only to the masked region.

        For B&W manga, also neutralizes any chroma drift in the a/b channels.

        Args:
            generated_pil: Generated patch from Flux Klein (at crop size)
            original_crop_pil: Original cropped region
            mask_crop_np: Boolean mask of inpaint region within crop
            verbose: Whether to print verbose output

        Returns:
            Luminance-corrected generated patch
        """
        context_mask = ~mask_crop_np
        if not np.any(context_mask) or not np.any(mask_crop_np):
            return generated_pil

        original_np = np.asarray(original_crop_pil)
        generated_np = np.asarray(generated_pil).copy()

        orig_mean, orig_std = self._compute_luminance_stats(original_np, context_mask)
        gen_mean, gen_std = self._compute_luminance_stats(generated_np, context_mask)

        if abs(orig_mean - gen_mean) < 1.3 and abs(orig_std - gen_std) < 2.0:
            return generated_pil

        scale = orig_std / gen_std
        scale = max(
            0.5, min(2.0, scale)
        )  # Prevent extreme stretching from degenerate distributions

        log_message(
            f"  - Luminance correction: mean {gen_mean:.1f}->{orig_mean:.1f}, "
            f"std {gen_std:.1f}->{orig_std:.1f} (scale={scale:.2f})",
            verbose=verbose,
        )

        lab = cv2.cvtColor(generated_np, cv2.COLOR_RGB2LAB).astype(np.float32)

        l_masked = lab[:, :, 0][mask_crop_np]
        lab[:, :, 0][mask_crop_np] = np.clip(
            (l_masked - gen_mean) * scale + orig_mean, 0, 255
        )

        # Neutralize chroma drift (Klein can introduce color casts on B&W content)
        orig_lab = cv2.cvtColor(original_np, cv2.COLOR_RGB2LAB).astype(np.float32)
        for ch in (1, 2):
            orig_ch_mean = float(np.mean(orig_lab[:, :, ch][context_mask]))
            gen_ch_mean = float(np.mean(lab[:, :, ch][context_mask]))
            ch_shift = orig_ch_mean - gen_ch_mean
            if abs(ch_shift) > 1.0:
                lab[:, :, ch][mask_crop_np] = np.clip(
                    lab[:, :, ch][mask_crop_np] + ch_shift, 0, 255
                )

        corrected_np = cv2.cvtColor(lab.astype(np.uint8), cv2.COLOR_LAB2RGB)
        return Image.fromarray(corrected_np)

    def _prepare_image_for_inference(
        self,
        image_pil: Image.Image,
        verbose: bool = False,
    ) -> Tuple[Image.Image, int, int]:
        """Prepare image for Klein inference.

        Optionally scales the image to approximately 1 megapixel while maintaining
        aspect ratio. When that scaling is disabled, large crops are still capped
        to 4MP. Dimensions are always kept within model constraints.

        Args:
            image_pil: Input PIL image
            verbose: Whether to print verbose output

        Returns:
            Tuple of (prepared image, original width, original height)
        """
        orig_w, orig_h = image_pil.size
        current_pixels = orig_w * orig_h

        if current_pixels <= 0:
            scale = 1.0
            reason = "model-compatible dimensions"
        elif self.upscale_small_crops:
            target_pixels = 1_048_576  # 2^20 = 1024x1024
            scale = math.sqrt(target_pixels / current_pixels)
            reason = "~1MP, multiples of 16"
        elif current_pixels > self.MAX_INFERENCE_PIXELS:
            scale = math.sqrt(self.MAX_INFERENCE_PIXELS / current_pixels)
            reason = "4MP cap, multiples of 16"
        else:
            scale = 1.0
            reason = "model-compatible dimensions"

        new_w = int(orig_w * scale)
        new_h = int(orig_h * scale)

        new_w = self._quantize_dimension(new_w)
        new_h = self._quantize_dimension(new_h)
        while new_w * new_h > self.MAX_INFERENCE_PIXELS:
            if new_w >= new_h and new_w > self.MIN_RESOLUTION:
                new_w -= self.RESOLUTION_MULTIPLE
            elif new_h > self.MIN_RESOLUTION:
                new_h -= self.RESOLUTION_MULTIPLE
            else:
                break

        if (new_w, new_h) != (orig_w, orig_h):
            log_message(
                f"  - Scaling {orig_w}x{orig_h} -> {new_w}x{new_h} ({reason})",
                verbose=verbose,
            )
            image_pil = image_pil.resize((new_w, new_h), Image.Resampling.LANCZOS)

        return image_pil, orig_w, orig_h

    def _run_sdcpp_inference(
        self,
        image_pil: Image.Image,
        width: int,
        height: int,
        seed: int,
        verbose: bool = False,
    ) -> Image.Image:
        if self.sdcpp_assets is None:
            raise ModelError("Flux.2 Klein sd.cpp server is not loaded.")

        payload = {
            "prompt": self.KLEIN_PROMPT,
            "negative_prompt": "",
            "width": int(width),
            "height": int(height),
            "seed": int(seed),
            "batch_count": 1,
            "ref_images": [pil_to_base64_png(image_pil)],
            "sample_params": {
                "sample_method": "euler",
                "sample_steps": int(self.num_inference_steps),
                "guidance": {
                    "txt_cfg": 1.0,
                    "img_cfg": 1.0,
                    "distilled_guidance": float(self.KLEIN_GUIDANCE_SCALE),
                },
            },
            "output_format": "png",
            "output_compression": 100,
        }
        return run_image_job(
            self.sdcpp_assets, payload, verbose=verbose, timeout_sec=900
        )

    def inpaint_mask(
        self,
        image_pil: Image.Image,
        mask_np: np.ndarray,
        seed: int = 1,
        verbose: bool = False,
        strict_mask_clipping: bool = False,
        composite_clip_bbox: Optional[Tuple[int, int, int, int]] = None,
        ocr_params: Optional[Dict] = None,
    ) -> Image.Image:
        """Inpaint a specific mask region in the image using Flux.2 Klein.

        Args:
            image_pil: PIL Image to inpaint
            mask_np: Numpy mask array (H, W) with True for areas to inpaint
            seed: Random seed for inference
            verbose: Whether to print verbose output
            strict_mask_clipping: When True, ensure compositing is limited to the
                original mask extent
            composite_clip_bbox: Optional (x1, y1, x2, y2) bbox to clip the final
                composite mask to
            ocr_params: Optional OCR parameters dict for cache key generation

        Returns:
            PIL.Image: The inpainted image
        """
        from scipy.ndimage import distance_transform_edt

        mask_np = np.asarray(mask_np)
        if mask_np.dtype != bool:
            mask_np = mask_np.astype(bool)

        if not np.any(mask_np):
            return image_pil

        log_message(
            f"  - Flux.2 Klein {self.variant.upper()} inpainting...", verbose=verbose
        )

        ys, xs = np.where(mask_np)
        if len(ys) == 0 or len(xs) == 0:
            return image_pil

        x_min, x_max = int(xs.min()), int(xs.max())
        y_min, y_max = int(ys.min()), int(ys.max())
        bbox_width = x_max - x_min
        bbox_height = y_max - y_min

        # Calculate context padding (doubled for Klein vs Kontext)
        padding_pixels = int(max(bbox_width, bbox_height) * CONTEXT_PADDING_RATIO)
        padding = int(
            min(padding_pixels, MAX_CONTEXT_PADDING) * self.KLEIN_PADDING_MULTIPLIER
        )

        blur_radius = int(max(bbox_width, bbox_height) * BLUR_SCALE_FACTOR)
        blur_radius = max(MIN_BLUR_RADIUS, min(blur_radius, MAX_BLUR_RADIUS))

        img_h, img_w = mask_np.shape
        x1 = max(0, x_min - padding)
        y1 = max(0, y_min - padding)
        x2 = min(img_w, x_max + 1 + padding)
        y2 = min(img_h, y_max + 1 + padding)
        x1, y1, x2, y2 = self._expand_bounds_to_min_size(x1, y1, x2, y2, img_w, img_h)

        width = min(self._quantize_dimension(x2 - x1), img_w)
        height = min(self._quantize_dimension(y2 - y1), img_h)

        if x1 + width > img_w:
            x1 = max(0, img_w - width)
        if y1 + height > img_h:
            y1 = max(0, img_h - height)
        x2 = x1 + width
        y2 = y1 + height
        width = x2 - x1
        height = y2 - y1

        if width <= 0 or height <= 0:
            log_message(
                f"  - Region has invalid size ({width}x{height}), skipping",
                verbose=verbose,
            )
            return image_pil

        log_message(
            f"  - Processing region at ({x1}, {y1}) size {width}x{height}",
            verbose=verbose,
        )

        image_cropped_pil = image_pil.crop((x1, y1, x2, y2))
        mask_crop_np = mask_np[y1:y2, x1:x2]

        # Build cache parameters
        cache_params = {
            "bbox": (x1, y1, width, height),
            "padding": padding,
            "blur": blur_radius,
            "variant": self.variant,
            "lum_corr": self.luminance_correction,
            "upscale_small": self.upscale_small_crops,
            "max_pixels": self.MAX_INFERENCE_PIXELS,
            "min_size": (self.MIN_RESOLUTION, self.MIN_RESOLUTION),
            "backend": self.backend,
        }
        if self.backend == "sdcpp":
            cache_params["sdcpp_cache"] = self.sdcpp_cache_mode
            cache_params["sdcpp_diffusion_quant"] = self.sdcpp_diffusion_quant
            cache_params["sdcpp_text_encoder_quant"] = self.sdcpp_text_encoder_quant
        if strict_mask_clipping:
            cache_params["strict_clip"] = True
        if composite_clip_bbox is not None:
            cache_params["clip_bbox"] = tuple(composite_clip_bbox)
        if ocr_params:
            cache_params.update(ocr_params)

        cache_key = None
        cached_patch = None
        if self.cache.should_use_inpaint_cache(seed):
            # Downsample mask signature to reduce sensitivity to minor jitter
            if mask_crop_np.size > 0:
                sig_h = min(64, max(4, mask_crop_np.shape[0]))
                sig_w = min(64, max(4, mask_crop_np.shape[1]))
                mask_sig = (
                    torch.from_numpy(mask_crop_np.astype(np.float32))
                    .unsqueeze(0)
                    .unsqueeze(0)
                )
                mask_sig = torch.nn.functional.interpolate(
                    mask_sig, size=(sig_h, sig_w), mode="bilinear", align_corners=False
                )
                mask_sig_np = (mask_sig > 0.5).cpu().numpy().astype(np.uint8)[0, 0]
            else:
                mask_sig_np = mask_crop_np

            cache_key = self.cache.get_inpaint_cache_key(
                image_cropped_pil,
                mask_sig_np,
                seed,
                self.num_inference_steps,
                0.0,  # Klein doesn't use residual_diff_threshold
                self.KLEIN_GUIDANCE_SCALE,
                self.KLEIN_PROMPT,
                cache_params,
            )
            cached_patch = self.cache.get_inpainted_image(cache_key)
            if cached_patch is not None:
                log_message("  - Using cached inpainting patch", verbose=verbose)

        mask_float = mask_crop_np.astype(np.float32)
        if blur_radius > 0:
            d_out = distance_transform_edt(~mask_crop_np)
            d_in = distance_transform_edt(mask_crop_np)
            alpha = np.zeros_like(d_out, np.float32)
            alpha[d_in > 0] = 1.0
            ramp = np.clip(1.0 - (d_out / blur_radius), 0.0, 1.0)
            alpha[d_out > 0] = ramp[d_out > 0]
            mask_for_composite = torch.from_numpy(alpha)[None, ...]
        else:
            mask_for_composite = torch.from_numpy(mask_float)[None, ...]

        if strict_mask_clipping:
            original_mask_crop = torch.from_numpy(mask_crop_np.astype(np.float32))
            mask_for_composite = mask_for_composite * original_mask_crop

        if composite_clip_bbox is not None:
            clip_x1, clip_y1, clip_x2, clip_y2 = composite_clip_bbox
            clip_x1 = max(0, min(img_w, clip_x1))
            clip_x2 = max(0, min(img_w, clip_x2))
            clip_y1 = max(0, min(img_h, clip_y1))
            clip_y2 = max(0, min(img_h, clip_y2))

            start_x = max(0, clip_x1 - x1)
            end_x = min(width, clip_x2 - x1)
            start_y = max(0, clip_y1 - y1)
            end_y = min(height, clip_y2 - y1)

            if end_x <= start_x or end_y <= start_y:
                mask_for_composite = torch.zeros_like(mask_for_composite)
            else:
                clipped_mask = torch.zeros_like(mask_for_composite)
                clipped_mask[:, start_y:end_y, start_x:end_x] = mask_for_composite[
                    :, start_y:end_y, start_x:end_x
                ]
                mask_for_composite = clipped_mask

        patch_pil = cached_patch

        if patch_pil is None:
            inference_image, _, _ = self._prepare_image_for_inference(
                image_cropped_pil,
                verbose=verbose,
            )
            inference_w, inference_h = inference_image.size

            if inference_image.mode == "RGBA":
                inference_image = inference_image.convert("RGB")

            log_message("  - Running inference...", verbose=verbose)

            with self.manager.flux_inference_lock:
                self.load_models()

                if self.pipeline is None:
                    log_message(
                        f"Warning: Flux Klein {self.variant.upper()} pipeline unavailable.",
                        always_print=True,
                    )
                    return image_pil

                if self.backend == "sdcpp":
                    generated_patch_pil = self._run_sdcpp_inference(
                        inference_image,
                        inference_w,
                        inference_h,
                        seed,
                        verbose=verbose or self.verbose,
                    )
                else:
                    with torch.inference_mode():
                        gen = torch.Generator(device=self.DEVICE).manual_seed(seed)
                        prompt_device = _pipeline_execution_device(
                            self.pipeline, self.DEVICE
                        )
                        prompt_embeds, pooled_prompt_embeds = (
                            self._get_prompt_embeddings(
                                prompt_device, verbose=verbose or self.verbose
                            )
                        )
                        out = self.pipeline(
                            **_flux_prompt_kwargs(
                                prompt_embeds,
                                pooled_prompt_embeds,
                                include_pooled=False,
                            ),
                            image=inference_image,
                            height=inference_h,
                            width=inference_w,
                            guidance_scale=self.KLEIN_GUIDANCE_SCALE,
                            num_inference_steps=self.num_inference_steps,
                            generator=gen,
                        )
                        generated_patch_pil = out.images[0]

            if (inference_w, inference_h) != (width, height):
                patch_pil = generated_patch_pil.resize(
                    (width, height), Image.Resampling.LANCZOS
                )
            else:
                patch_pil = generated_patch_pil

            if self.luminance_correction:
                patch_pil = self._match_luminance(
                    generated_pil=patch_pil,
                    original_crop_pil=image_cropped_pil,
                    mask_crop_np=mask_crop_np,
                    verbose=verbose,
                )

        dest_tensor = torch.from_numpy(
            np.asarray(image_pil, dtype=np.float32) / 255.0
        ).unsqueeze(0)
        src_tensor = torch.from_numpy(
            np.asarray(patch_pil, dtype=np.float32) / 255.0
        ).unsqueeze(0)

        # Fix channel mismatch (e.g. RGBA destination vs RGB source)
        dest_channels = dest_tensor.shape[-1]
        src_channels = src_tensor.shape[-1]

        if dest_channels > src_channels:
            padding = torch.ones(
                (*src_tensor.shape[:-1], dest_channels - src_channels),
                device=src_tensor.device,
                dtype=src_tensor.dtype,
            )
            src_tensor = torch.cat([src_tensor, padding], dim=-1)
        elif src_channels > dest_channels:
            src_tensor = src_tensor[..., :dest_channels]

        # Use FluxKontextInpainter's composite method (same logic)
        dest_tensor = dest_tensor.movedim(-1, 1)
        src_tensor = src_tensor.movedim(-1, 1)

        mask_interp = torch.nn.functional.interpolate(
            mask_for_composite.reshape(
                (-1, 1, mask_for_composite.shape[-2], mask_for_composite.shape[-1])
            ),
            size=(src_tensor.shape[2], src_tensor.shape[3]),
            mode="bilinear",
        )

        composited = dest_tensor.clone()
        visible_h = min(src_tensor.shape[2], dest_tensor.shape[2] - y1)
        visible_w = min(src_tensor.shape[3], dest_tensor.shape[3] - x1)

        if visible_h > 0 and visible_w > 0:
            src_portion = src_tensor[:, :, :visible_h, :visible_w]
            mask_portion = mask_interp[:, :, :visible_h, :visible_w]
            dest_portion = composited[:, :, y1 : y1 + visible_h, x1 : x1 + visible_w]

            blended = src_portion * mask_portion + dest_portion * (1 - mask_portion)
            composited[:, :, y1 : y1 + visible_h, x1 : x1 + visible_w] = blended

        composited = composited.movedim(1, -1)
        composited_pil = Image.fromarray(
            (composited[0].cpu().numpy() * 255).astype("uint8")
        )

        # Save to cache if generated (not from cache)
        if (
            self.cache.should_use_inpaint_cache(seed)
            and cache_key is not None
            and cached_patch is None
        ):
            self.cache.set_inpainted_image(cache_key, patch_pil)

        return composited_pil
