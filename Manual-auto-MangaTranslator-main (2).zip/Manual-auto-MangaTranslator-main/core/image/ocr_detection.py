import os
from typing import List, Optional, Tuple

import cv2
import numpy as np
import torch
from PIL import Image

from core.caching import get_cache
from core.device import get_best_device
from core.ml.model_manager import ModelType, get_model_manager
from utils.exceptions import ImageProcessingError
from utils.logging import log_message

# OSB Detection Parameters
OSB_BUBBLE_MATCH_IOA_THRESHOLD = (
    0.2  # Minimum text-box overlap ratio for OSB assignment
)
TEXT_FREE_BUBBLE_IOA_THRESHOLD = (
    0.5  # Bubble treated as text_free only with substantial overlap
)


class OutsideTextDetector:
    """Detects text outside speech bubbles to isolate SFX/captions from dialogue."""

    def __init__(
        self,
        device: Optional[torch.device] = None,
        hf_token: Optional[str] = None,
    ):
        """Initialize the outside text detector.

        Args:
            device: PyTorch device to use. Auto-detects if None.
            hf_token: Hugging Face token for gated repo access.
        """
        self.device = device if device is not None else get_best_device()
        self.hf_token = hf_token
        self.manager = get_model_manager()
        self.cache = get_cache()

    def boxes_overlap(self, box1, box2):
        """Check if two bounding boxes overlap (have non-zero intersection).

        Args:
            box1: Bounding box in [x_min, y_min, x_max, y_max] format.
            box2: Bounding box in YOLO format [x_min, y_min, x_max, y_max].

        Returns:
            bool: True if boxes overlap, False otherwise.
        """
        x1_min, y1_min, x1_max, y1_max = box1
        x2_min, y2_min, x2_max, y2_max = box2

        return not (
            x1_max <= x2_min or x2_max <= x1_min or y1_max <= y2_min or y2_max <= y1_min
        )

    def box_intersection_area(self, box1, box2) -> float:
        """Return the intersection area between two xyxy boxes."""
        x_min = max(box1[0], box2[0])
        y_min = max(box1[1], box2[1])
        x_max = min(box1[2], box2[2])
        y_max = min(box1[3], box2[3])
        return max(0.0, x_max - x_min) * max(0.0, y_max - y_min)

    def box_area(self, box) -> float:
        """Return the area of an xyxy box."""
        return max(0.0, box[2] - box[0]) * max(0.0, box[3] - box[1])

    def point_in_box(self, point_x: float, point_y: float, box) -> bool:
        """Return True if a point lies inside an xyxy box."""
        return box[0] <= point_x <= box[2] and box[1] <= point_y <= box[3]

    def text_box_meaningfully_matches_bubble(self, text_box, bubble_box) -> bool:
        """Return True when a text box meaningfully belongs to a bubble box."""
        intersection = self.box_intersection_area(text_box, bubble_box)
        if intersection <= 0.0:
            return False

        text_area = self.box_area(text_box)
        if text_area <= 0.0:
            return False

        center_x = (text_box[0] + text_box[2]) / 2.0
        center_y = (text_box[1] + text_box[3]) / 2.0
        return (
            intersection / text_area >= OSB_BUBBLE_MATCH_IOA_THRESHOLD
            or self.point_in_box(center_x, center_y, bubble_box)
        )

    def box_is_inside(self, box1, box2, threshold=0.9):
        """Check if box1 is significantly contained inside box2 (IoA > threshold).

        Args:
            box1: Inner bounding box [x1, y1, x2, y2].
            box2: Outer bounding box [x1, y1, x2, y2].
            threshold: Intersection over Area threshold (default 0.9).

        Returns:
            bool: True if box1 is contained in box2, False otherwise.
        """
        x1_min, y1_min, x1_max, y1_max = box1
        x2_min, y2_min, x2_max, y2_max = box2

        inter_x_min = max(x1_min, x2_min)
        inter_y_min = max(y1_min, y2_min)
        inter_x_max = min(x1_max, x2_max)
        inter_y_max = min(y1_max, y2_max)

        inter_w = max(0, inter_x_max - inter_x_min)
        inter_h = max(0, inter_y_max - inter_y_min)
        intersection = inter_w * inter_h

        area1 = (x1_max - x1_min) * (y1_max - y1_min)

        if area1 <= 0:
            return False

        ioa = intersection / area1
        return ioa > threshold

    def box_ioa(self, box_inner, box_outer) -> float:
        """IoA = intersection_area / area_of_inner_box."""
        area_inner = self.box_area(box_inner)
        if area_inner <= 0.0:
            return 0.0
        return self.box_intersection_area(box_inner, box_outer) / area_inner

    def bubble_is_text_free_region(self, bubble_box, text_free_boxes) -> bool:
        """Return True if a bubble box is substantially the same as a text_free box.

        Requires real IoA overlap, not a one-pixel touch. Adjacent dialogue
        bubbles must still suppress in-bubble OSB text detections.
        """
        if not text_free_boxes:
            return False
        for tf_box in text_free_boxes:
            tf = list(map(float, tf_box[:4]))
            bubble = list(map(float, bubble_box[:4]))
            if (
                self.box_ioa(bubble, tf) > TEXT_FREE_BUBBLE_IOA_THRESHOLD
                or self.box_ioa(tf, bubble) > TEXT_FREE_BUBBLE_IOA_THRESHOLD
            ):
                return True
        return False

    def filter_nested_detections(self, results):
        """Remove detections fully contained in larger ones to avoid duplicates.

        Args:
            results: List of detection results (bbox, text, confidence).

        Returns:
            list: Filtered results with nested detections removed.
        """
        if len(results) <= 1:
            return results

        # Prioritize larger detections to avoid removing important text
        def get_area(result):
            bbox = result[0]
            x_min, y_min, x_max, y_max = bbox
            return (x_max - x_min) * (y_max - y_min)

        sorted_results = sorted(results, key=get_area, reverse=True)
        filtered_results = []

        for i, current_result in enumerate(sorted_results):
            is_nested = False
            current_bbox = current_result[0]

            for kept_result in filtered_results:
                kept_bbox = kept_result[0]
                if self.box_is_inside(current_bbox, kept_bbox):
                    is_nested = True
                    break

            if not is_nested:
                filtered_results.append(current_result)

        return filtered_results

    def unload_models(self):
        """Unload OCR models via model manager to free GPU/CPU memory."""
        self.manager.unload_ocr_models()

    def detect_outside_text(
        self,
        image_path: str,
        yolo_model_path: Optional[str] = None,
        confidence: float = 0.6,
        conjoined_confidence: float = 0.35,
        verbose: bool = False,
        image_override: Optional[Image.Image] = None,
        existing_bubbles: Optional[List] = None,
        text_free_boxes: Optional[List] = None,
        bubble_detector_model: str = "yolo_2",
        min_area_ignore_ratio: float = 0.0,
    ):
        """Detect non-dialogue text by subtracting YOLO speech bubbles from OCR results.

        Args:
            image_path: Path to the input image.
            yolo_model_path: Optional custom YOLO model path.
            confidence: Confidence threshold for primary YOLO model detections.
            conjoined_confidence: Confidence threshold for secondary RT-DETR model (conjoined bubble detection).
            verbose: If True, logs intermediate steps.
            text_free_boxes: Optional list of text_free regions to use as fallback OSB detections.

        Returns:
            list: Detected regions outside bubbles as (bbox, confidence).
        """
        if image_override is None and not os.path.exists(image_path):
            raise FileNotFoundError(f"Error: The file '{image_path}' was not found.")

        try:
            if image_override is not None:
                image_pil = (
                    image_override
                    if image_override.mode == "RGB"
                    else image_override.convert("RGB")
                )
                image_cv = cv2.cvtColor(np.array(image_pil), cv2.COLOR_RGB2BGR)
            else:
                image_cv = cv2.imread(str(image_path))
                if image_cv is None:
                    raise ImageProcessingError(f"Could not read image at {image_path}")
                image_pil = Image.fromarray(cv2.cvtColor(image_cv, cv2.COLOR_BGR2RGB))
            image_name = image_path if image_override is None else "override"
            log_message(
                f"Processing image: {image_name} "
                f"({image_cv.shape[1]}x{image_cv.shape[0]})",
                verbose=verbose,
            )
        except Exception as e:
            raise ImageProcessingError(f"Error loading image: {e}")

        provided_bubble_boxes = None
        if existing_bubbles is not None:
            try:
                provided_bubble_boxes = []
                for b in existing_bubbles:
                    bbox = b.get("bbox") if isinstance(b, dict) else b
                    if bbox is None or len(bbox) != 4:
                        continue
                    x0, y0, x1, y1 = bbox
                    provided_bubble_boxes.append(
                        [float(x0), float(y0), float(x1), float(y1)]
                    )
                if provided_bubble_boxes:
                    log_message(
                        f"Using {len(provided_bubble_boxes)} provided bubble boxes for OSB filtering",
                        verbose=verbose,
                    )
            except Exception as e:
                log_message(
                    f"Warning: Failed to parse provided bubbles: {e}. Falling back to YOLO.",
                    always_print=True,
                )
                provided_bubble_boxes = None

        text_free_boxes = list(text_free_boxes) if text_free_boxes else []

        if provided_bubble_boxes:
            yolo_boxes = torch.tensor(
                provided_bubble_boxes, device=self.device, dtype=torch.float32
            )
            num_yolo_boxes = len(yolo_boxes)
            log_message(
                f"Skipping YOLO; using provided bubbles ({num_yolo_boxes})",
                verbose=verbose,
            )
        else:
            log_message("Running YOLO detection for speech bubbles...", verbose=verbose)

            sb_model_path = (
                str(self.manager.model_paths[ModelType.YOLO_SPEECH_BUBBLE])
                if yolo_model_path is None
                else yolo_model_path
            )
            sb_cache_key = self.cache.get_yolo_cache_key(
                image_pil, sb_model_path, confidence
            )
            cached_sb = self.cache.get_yolo_detection(sb_cache_key)

            if cached_sb is not None:
                log_message("Using cached Speech Bubble detections", verbose=verbose)
                yolo_results, yolo_boxes = cached_sb
            else:
                yolo_model = self.manager.load_yolo_speech_bubble(yolo_model_path)
                yolo_results = yolo_model(
                    image_cv,
                    conf=confidence,
                    device=self.device,
                    verbose=False,
                    imgsz=1600 if bubble_detector_model == "yolo_2" else 640,
                    retina_masks=True,
                )[0]
                yolo_boxes = (
                    yolo_results.boxes.xyxy
                    if yolo_results.boxes is not None
                    else torch.tensor([])
                )
                self.cache.set_yolo_detection(sb_cache_key, (yolo_results, yolo_boxes))

            num_yolo_boxes = len(yolo_boxes) if yolo_boxes.nelement() > 0 else 0
            log_message(
                f"YOLO detected {num_yolo_boxes} speech bubbles", verbose=verbose
            )

            log_message(
                "Running secondary RT-DETR to catch missed bubbles...", verbose=verbose
            )
            try:
                sec_model = self.manager.load_rtdetr_conjoined_bubble()
                sec_results = sec_model(
                    image_cv,
                    conf=conjoined_confidence,
                    device=self.device,
                    verbose=False,
                    imgsz=640,
                )[0]

                sec_boxes = (
                    sec_results.boxes.xyxy
                    if sec_results.boxes is not None
                    else torch.tensor([])
                )
                sec_cls = (
                    sec_results.boxes.cls
                    if sec_results.boxes is not None
                    else torch.tensor([])
                )

                # bubble = speech bubbles; text_free = OSB; ignore text_bubble (in-bubble text)
                bubble_id = None
                tf_id = None
                if hasattr(sec_model, "names"):
                    for cid, cname in sec_model.names.items():
                        if cname == "bubble":
                            bubble_id = cid
                        elif cname == "text_free":
                            tf_id = cid

                if tf_id is not None and len(sec_boxes) > 0:
                    for i, cls_id in enumerate(sec_cls):
                        if int(cls_id) == tf_id:
                            text_free_boxes.append(sec_boxes[i].detach().cpu().numpy())

                if bubble_id is not None and len(sec_boxes) > 0:
                    boxes_to_add = []
                    for i, cls_id in enumerate(sec_cls):
                        if int(cls_id) == bubble_id:
                            boxes_to_add.append(sec_boxes[i])

                    if boxes_to_add:
                        log_message(
                            f"Secondary RT-DETR found {len(boxes_to_add)} potential bubbles",
                            verbose=verbose,
                        )
                        boxes_to_add_tensor = torch.stack(boxes_to_add)
                        if yolo_boxes.nelement() > 0:
                            yolo_boxes = torch.cat(
                                (yolo_boxes, boxes_to_add_tensor), dim=0
                            )
                        else:
                            yolo_boxes = boxes_to_add_tensor
            except Exception as e:
                log_message(f"Secondary RT-DETR failed: {e}", verbose=verbose)

        log_message("Running YOLO OSB Text...", always_print=True)

        osbtext_boxes = None
        osbtext_confs = None
        try:
            osbtext_model_path = str(self.manager.model_paths[ModelType.YOLO_OSBTEXT])
            osbtext_cache_key = self.cache.get_yolo_cache_key(
                image_pil, osbtext_model_path, confidence
            )

            cached_osbtext = self.cache.get_yolo_detection(osbtext_cache_key)

            if cached_osbtext is not None:
                log_message("Using cached OSBText detections", verbose=verbose)
                osbtext_results, osbtext_boxes, osbtext_confs = cached_osbtext
            else:
                osbtext_model = self.manager.load_yolo_osbtext(token=self.hf_token)
                osbtext_results = osbtext_model(
                    image_cv,
                    conf=confidence,
                    device=self.device,
                    verbose=False,
                    imgsz=640,
                )[0]
                osbtext_boxes = (
                    osbtext_results.boxes.xyxy
                    if osbtext_results.boxes is not None
                    else None
                )
                osbtext_confs = (
                    osbtext_results.boxes.conf
                    if osbtext_results.boxes is not None
                    else None
                )
                self.cache.set_yolo_detection(
                    osbtext_cache_key, (osbtext_results, osbtext_boxes, osbtext_confs)
                )
        except Exception as e:
            log_message(
                f"OSB text model unavailable: {e}. Using text_free fallback if available.",
                always_print=True,
            )
            if text_free_boxes:
                log_message(
                    f"Using {len(text_free_boxes)} text_free boxes as OSB fallback",
                    always_print=True,
                )
                osbtext_boxes = torch.tensor(
                    text_free_boxes, device=self.device, dtype=torch.float32
                )
                osbtext_confs = torch.ones(
                    len(text_free_boxes), device=self.device, dtype=torch.float32
                )
            else:
                log_message(
                    "No text_free fallback available; skipping OSB text detections",
                    always_print=True,
                )

        base_results = []
        if osbtext_boxes is not None:
            boxes_np = osbtext_boxes.detach().cpu().numpy()
            confs_np = osbtext_confs.detach().cpu().numpy()

            for i, box in enumerate(boxes_np):
                conf = confs_np[i]
                base_results.append((box, float(conf)))

        final_results = list(base_results)

        log_message("Filtering out nested detections...", verbose=verbose)
        before_nested_filter = len(final_results)
        final_results = self.filter_nested_detections(final_results)
        after_nested_filter = len(final_results)
        nested_removed = before_nested_filter - after_nested_filter
        log_message(
            f"Nested detections removed: {nested_removed}. Remaining detections: {after_nested_filter}.",
            verbose=verbose,
        )

        if yolo_boxes is not None and yolo_boxes.nelement() > 0:
            log_message(
                "Filtering OCR results to keep text outside speech bubbles...",
                verbose=verbose,
            )
            filtered_results = []
            yolo_boxes_np = yolo_boxes.detach().cpu().numpy()

            for ocr_result in final_results:
                bbox, _ = ocr_result

                best_bubble = None
                best_intersection = 0.0

                for yolo_box in yolo_boxes_np:
                    if self.boxes_overlap(bbox, yolo_box):
                        if self.bubble_is_text_free_region(yolo_box, text_free_boxes):
                            continue

                        intersection = self.box_intersection_area(bbox, yolo_box)
                        if intersection > best_intersection:
                            best_intersection = intersection
                            best_bubble = yolo_box

                if best_bubble is None or not self.text_box_meaningfully_matches_bubble(
                    bbox, best_bubble
                ):
                    filtered_results.append(ocr_result)

            filtered_out = len(final_results) - len(filtered_results)
            log_message(
                f"Filtered out {filtered_out} OCR results that meaningfully overlapped speech bubbles",
                verbose=verbose,
            )
            final_results = filtered_results

        found_count = len(final_results)
        min_ignore = max(0.0, min(0.05, min_area_ignore_ratio))
        if min_ignore > 0.0:
            image_area = float(image_pil.width * image_pil.height)
            ignored_count = sum(
                1
                for bbox, _ in final_results
                if ((bbox[2] - bbox[0]) * (bbox[3] - bbox[1])) / max(1.0, image_area)
                < min_ignore
            )
            found_count -= ignored_count

        log_message(f"Found {found_count} outside text regions", always_print=True)

        return final_results

    def get_text_masks(
        self,
        image_path: str,
        bbox_expansion_percent: float = 0.0,
        text_box_proximity_ratio: float = 0.02,
        verbose: bool = False,
        image_override: Optional[Image.Image] = None,
        existing_results: Optional[List] = None,
    ) -> Tuple[Optional[List], Optional[Image.Image]]:
        """Create rectangular masks from OCR bounding boxes for inpainting.

        Args:
            image_path: Path to the input image.
            bbox_expansion_percent: Percentage to expand bounding boxes.
            text_box_proximity_ratio: Ratio for grouping nearby text boxes (as fraction of image dimension).
            verbose: Whether to print verbose output.

        Returns:
            tuple: (groups, image_pil) where groups is a list of dicts with:
                {
                    'combined_mask': np.array[H,W,bool],
                    'bbox': dict,
                    'individual_masks': [np.array],
                    'mask_indices': [int],
                    'confidence': float,
                }.
        """
        results = (
            existing_results
            if existing_results is not None
            else self.detect_outside_text(
                image_path,
                verbose=verbose,
                image_override=image_override,
            )
        )

        if not results:
            return None, None

        if image_override is not None:
            image_pil = (
                image_override.convert("RGB")
                if image_override.mode != "RGB"
                else image_override
            )
        else:
            image_pil = Image.open(image_path).convert("RGB")
        img_w, img_h = image_pil.size

        log_message("Converting OCR results to axis-aligned boxes...", verbose=verbose)
        boxes = [[int(c) for c in result[0]] for result in results]

        expanded_boxes = []
        for box in boxes:
            x0, y0, x1, y1 = box
            width = x1 - x0
            height = y1 - y0
            expand_x = width * bbox_expansion_percent
            expand_y = height * bbox_expansion_percent
            x0e = int(np.floor(max(0, x0 - expand_x)))
            y0e = int(np.floor(max(0, y0 - expand_y)))
            x1e = int(np.ceil(min(img_w, x1 + expand_x)))
            y1e = int(np.ceil(min(img_h, y1 + expand_y)))
            if x1e > x0e and y1e > y0e:
                expanded_boxes.append([x0e, y0e, x1e, y1e])

        log_message(
            f"Grouping {len(expanded_boxes)} text boxes spatially...",
            verbose=verbose,
        )

        grouped_boxes = self._group_text_boxes_spatially(
            expanded_boxes, results, img_w, img_h, text_box_proximity_ratio, verbose
        )

        groups = []
        for group_boxes, group_results, global_indices in grouped_boxes:
            combined_mask = np.zeros((img_h, img_w), dtype=bool)
            individual_masks = []
            mask_indices = []
            avg_confidence = 0.0

            min_x = min(box[0] for box in group_boxes)
            min_y = min(box[1] for box in group_boxes)
            max_x = max(box[2] for box in group_boxes)
            max_y = max(box[3] for box in group_boxes)

            # Ensure combined region doesn't exceed Flux Kontext preferred resolutions
            max_dimension = 1568
            if max_x - min_x > max_dimension or max_y - min_y > max_dimension:
                log_message(
                    f"  - Group too large ({max_x - min_x}x{max_y - min_y}), splitting...",
                    verbose=verbose,
                )
                for i, (box, result, g_idx) in enumerate(
                    zip(group_boxes, group_results, global_indices)
                ):
                    x0, y0, x1, y1 = box
                    mask = np.zeros((img_h, img_w), dtype=bool)
                    mask[y0:y1, x0:x1] = True

                    bbox = {
                        "x": int(x0),
                        "y": int(y0),
                        "width": int(x1 - x0),
                        "height": int(y1 - y0),
                    }

                    raw_box = [int(c) for c in result[0]]
                    raw_x0, raw_y0, raw_x1, raw_y1 = raw_box
                    original_bbox = {
                        "x": raw_x0,
                        "y": raw_y0,
                        "width": raw_x1 - raw_x0,
                        "height": raw_y1 - raw_y0,
                    }

                    _, conf = result

                    groups.append(
                        {
                            "combined_mask": mask,
                            "bbox": bbox,
                            "original_bbox": original_bbox,
                            "individual_masks": [mask],
                            "mask_indices": [g_idx],
                            "confidence": conf,
                        }
                    )
                continue

            raw_boxes = [[int(c) for c in res[0]] for res in group_results]

            for i, (box, result, raw_box, g_idx) in enumerate(
                zip(group_boxes, group_results, raw_boxes, global_indices)
            ):
                x0, y0, x1, y1 = box
                mask = np.zeros((img_h, img_w), dtype=bool)
                mask[y0:y1, x0:x1] = True

                combined_mask |= mask
                individual_masks.append(mask)
                mask_indices.append(g_idx)

                _, conf = result
                avg_confidence += conf

            raw_min_x = min(box[0] for box in raw_boxes)
            raw_min_y = min(box[1] for box in raw_boxes)
            raw_max_x = max(box[2] for box in raw_boxes)
            raw_max_y = max(box[3] for box in raw_boxes)

            bbox = {
                "x": int(min_x),
                "y": int(min_y),
                "width": int(max_x - min_x),
                "height": int(max_y - min_y),
            }

            original_bbox = {
                "x": int(raw_min_x),
                "y": int(raw_min_y),
                "width": int(raw_max_x - raw_min_x),
                "height": int(raw_max_y - raw_min_y),
            }

            groups.append(
                {
                    "combined_mask": combined_mask,
                    "bbox": bbox,
                    "original_bbox": original_bbox,
                    "individual_masks": individual_masks,
                    "mask_indices": mask_indices,
                    "confidence": avg_confidence / len(group_results),
                }
            )

        log_message(
            f"Created {len(groups)} grouped text regions for inpainting",
            verbose=verbose,
        )

        return groups, image_pil

    def _group_text_boxes_spatially(
        self, boxes, results, img_w, img_h, text_box_proximity_ratio=0.02, verbose=False
    ):
        """
        Group nearby text boxes based on spatial proximity.

        Args:
            boxes: List of bounding boxes [x0, y0, x1, y1]
            results: List of OCR results corresponding to boxes
            img_w: Image width
            img_h: Image height
            text_box_proximity_ratio: Ratio for grouping nearby text boxes (as fraction of image dimension).
            verbose: Whether to print detailed logs

        Returns:
            List of tuples (group_boxes, group_results) where each group contains
            spatially related text boxes
        """
        if not boxes:
            return []

        proximity_threshold = min(img_w, img_h) * text_box_proximity_ratio

        parent = list(range(len(boxes)))

        def find(x):
            if parent[x] != x:
                parent[x] = find(parent[x])
            return parent[x]

        def union(x, y):
            px, py = find(x), find(y)
            if px != py:
                parent[px] = py

        for i in range(len(boxes)):
            for j in range(i + 1, len(boxes)):
                if self._boxes_are_nearby(boxes[i], boxes[j], proximity_threshold):
                    union(i, j)

        groups = {}
        for i in range(len(boxes)):
            root = find(i)
            if root not in groups:
                groups[root] = ([], [], [])
            groups[root][0].append(boxes[i])
            groups[root][1].append(results[i])
            groups[root][2].append(i)

        grouped_boxes = list(groups.values())

        log_message(
            f"  - Grouped {len(boxes)} boxes into {len(grouped_boxes)} spatial groups",
            verbose=verbose,
        )

        return grouped_boxes

    def _boxes_are_nearby(self, box1, box2, threshold):
        """
        Check if two bounding boxes are spatially close enough to be grouped.

        Args:
            box1: First bounding box [x0, y0, x1, y1]
            box2: Second bounding box [x0, y0, x1, y1]
            threshold: Maximum distance for boxes to be considered nearby

        Returns:
            True if boxes are nearby, False otherwise
        """
        x1_min, y1_min, x1_max, y1_max = box1
        x2_min, y2_min, x2_max, y2_max = box2

        cx1 = (x1_min + x1_max) / 2
        cy1 = (y1_min + y1_max) / 2
        cx2 = (x2_min + x2_max) / 2
        cy2 = (y2_min + y2_max) / 2

        distance = np.sqrt((cx1 - cx2) ** 2 + (cy1 - cy2) ** 2)

        return distance <= threshold


def extract_text_with_manga_ocr(
    images: List[Image.Image], verbose: bool = False
) -> List[str]:
    """Extract text from images using manga-ocr library.

    Args:
        images: List of PIL Images to process
        verbose: Whether to print verbose output

    Returns:
        List of extracted text strings (one per image). Returns [OCR FAILED] on errors.
    """
    if not images:
        return []

    try:
        model_manager = get_model_manager()
        manga_ocr_instance = model_manager.get_manga_ocr(verbose=verbose)

        extracted_texts = []
        for i, img in enumerate(images):
            try:
                if img is None:
                    log_message(
                        f"Image {i + 1} is None (decode failure), skipping",
                        always_print=True,
                    )
                    extracted_texts.append("[OCR FAILED]")
                    continue

                log_message(
                    f"Processing image {i + 1}/{len(images)} with manga-ocr",
                    verbose=verbose,
                )
                text = manga_ocr_instance(img)

                extracted_texts.append(text.strip() if text else "")

            except Exception as e:
                log_message(
                    f"manga-ocr failed for image {i + 1}: {e}", always_print=True
                )
                extracted_texts.append("[OCR FAILED]")

        return extracted_texts

    except Exception as e:
        log_message(f"Error with manga-ocr: {e}", always_print=True)
        return ["[OCR FAILED]"] * len(images)


def _get_image_size_value(size_config, key: str):
    if isinstance(size_config, dict):
        return size_config.get(key)
    return getattr(size_config, key, None)


def _get_paddle_ocr_vl_size(processor, max_pixels: int) -> dict:
    image_processor = processor.image_processor
    size_config = getattr(image_processor, "size", {}) or {}

    shortest_edge = getattr(image_processor, "min_pixels", None)
    if shortest_edge is None:
        shortest_edge = _get_image_size_value(size_config, "shortest_edge")
    if shortest_edge is None:
        shortest_edge = _get_image_size_value(size_config, "min_pixels")
    if shortest_edge is None:
        shortest_edge = 28 * 28 * 130

    return {
        "shortest_edge": shortest_edge,
        "longest_edge": max_pixels,
    }


def extract_text_with_paddle_ocr_vl(
    images: List[Image.Image], verbose: bool = False
) -> List[str]:
    """Extract text from images using PaddleOCR-VL-1.6.

    Args:
        images: List of PIL Images to process (RGB)
        verbose: Whether to print verbose output

    Returns:
        List of extracted text strings (one per image). Returns [OCR FAILED] on errors.
    """
    if not images:
        return []

    try:
        model_manager = get_model_manager()
        processor, model = model_manager.get_paddle_ocr_vl(verbose=verbose)

        max_pixels = 1280 * 28 * 28
        image_size = _get_paddle_ocr_vl_size(processor, max_pixels)

        extracted_texts = []
        for i, img in enumerate(images):
            try:
                if img is None:
                    log_message(
                        f"Image {i + 1} is None (decode failure), skipping",
                        always_print=True,
                    )
                    extracted_texts.append("[OCR FAILED]")
                    continue

                log_message(
                    f"Processing image {i + 1}/{len(images)} with PaddleOCR-VL-1.6",
                    verbose=verbose,
                )

                messages = [
                    {
                        "role": "user",
                        "content": [
                            {"type": "image", "image": img},
                            {"type": "text", "text": "OCR:"},
                        ],
                    }
                ]
                inputs = processor.apply_chat_template(
                    messages,
                    add_generation_prompt=True,
                    tokenize=True,
                    return_dict=True,
                    return_tensors="pt",
                    processor_kwargs={
                        "images_kwargs": {
                            "size": image_size,
                        },
                    },
                ).to(model.device)

                outputs = model.generate(**inputs, max_new_tokens=1024)

                text = processor.decode(outputs[0][inputs["input_ids"].shape[-1] : -1])
                extracted_texts.append(text.strip() if text else "")

            except Exception as e:
                log_message(
                    f"PaddleOCR-VL-1.6 failed for image {i + 1}: {e}",
                    always_print=True,
                )
                extracted_texts.append("[OCR FAILED]")

        return extracted_texts

    except Exception as e:
        log_message(f"Error with PaddleOCR-VL-1.6: {e}", always_print=True)
        return ["[OCR FAILED]"] * len(images)


# Maps the engine's free-text `input_language` (as forwarded via
# --input-language, e.g. "Japanese", "ja", "Korean", "ko", "Chinese", "zh",
# "auto") to the classic-PaddleOCR `lang` model identifier to load. Falls
# back to a multi-language guess (all three CJK languages) when the input
# language is unset/unrecognized (e.g. "auto"), since manga/manhwa/manhua
# batches are frequently mixed and callers would rather pay a small accuracy
# cost than get an outright wrong-language load.
_CJK_LANGUAGE_ALIASES = {
    "japanese": "japanese",
    "ja": "japanese",
    "jp": "japanese",
    "jpn": "japanese",
    "korean": "korean",
    "ko": "korean",
    "kr": "korean",
    "kor": "korean",
    "chinese": "chinese",
    "zh": "chinese",
    "zh-cn": "chinese",
    "zh-tw": "chinese",
    "cn": "chinese",
    "chi": "chinese",
    "english": "english",
    "en": "english",
    "eng": "english",
}

# Classic PaddleOCR (PP-OCRv4) `lang=` model identifiers. Note PaddleOCR uses
# its own naming ("japan"/"korean"/"ch") rather than ISO codes.
_PADDLE_CLASSIC_LANG_CODES = {
    "japanese": "japan",
    "korean": "korean",
    "chinese": "ch",  # "ch" model also recognizes English/digits alongside Chinese
    "english": "en",
}


def _normalize_input_language(input_language: Optional[str]) -> Optional[str]:
    """Normalize a free-text input_language into one of
    'japanese'/'korean'/'chinese'/'english', or None if unset/unrecognized
    (e.g. "auto"), in which case callers should treat the batch as
    multi-language (manga+manhwa+manhua mixed).
    """
    if not input_language:
        return None
    key = input_language.strip().lower()
    return _CJK_LANGUAGE_ALIASES.get(key)


def extract_text_with_classic_paddleocr(
    images: List[Image.Image],
    input_language: Optional[str] = None,
    verbose: bool = False,
) -> List[str]:
    """Extract text from images using classic PaddleOCR (PP-OCRv4 detection +
    recognition), NOT PaddleOCR-VL. This is a fast, non-VLM CPU-friendly OCR
    engine, loaded per-language (Japanese/Korean/Chinese/English) so it can
    cover manga, manhwa, and manhua.

    Args:
        images: List of PIL Images to process (RGB)
        input_language: Source language hint (e.g. "Japanese", "ko", "auto").
            Selects which PP-OCRv4 language model to run. When unset/
            unrecognized (e.g. "auto"), each image is tried against
            Japanese, Korean, and Chinese models in turn and the result
            with the most recognized text lines is kept, since PP-OCRv4
            does not support multiple recognition languages in one pass.
        verbose: Whether to print verbose output

    Returns:
        List of extracted text strings (one per image). Returns [OCR FAILED] on errors.
    """
    if not images:
        return []

    try:
        model_manager = get_model_manager()
        normalized_lang = _normalize_input_language(input_language)

        if normalized_lang is not None:
            candidate_langs = [_PADDLE_CLASSIC_LANG_CODES[normalized_lang]]
        else:
            # No reliable language hint: try the three CJK models per image
            # and keep whichever recognized the most text. Slower, but
            # correct behavior for mixed/auto-detect manga+manhwa+manhua
            # batches, which is the whole point of adding multi-language
            # support here.
            candidate_langs = [
                _PADDLE_CLASSIC_LANG_CODES["japanese"],
                _PADDLE_CLASSIC_LANG_CODES["korean"],
                _PADDLE_CLASSIC_LANG_CODES["chinese"],
            ]

        extracted_texts = []
        for i, img in enumerate(images):
            try:
                if img is None:
                    log_message(
                        f"Image {i + 1} is None (decode failure), skipping",
                        always_print=True,
                    )
                    extracted_texts.append("[OCR FAILED]")
                    continue

                log_message(
                    f"Processing image {i + 1}/{len(images)} with PaddleOCR (Classic)",
                    verbose=verbose,
                )

                img_np = cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)

                best_text = ""
                best_line_count = -1
                for lang_code in candidate_langs:
                    ocr_instance = model_manager.get_paddleocr_classic(
                        lang=lang_code, verbose=verbose
                    )
                    result = ocr_instance.predict(img_np)

                    lines: List[str] = []
                    for res in result or []:
                        res_dict = res if isinstance(res, dict) else getattr(
                            res, "json", {}
                        ).get("res", {})
                        rec_texts = res_dict.get("rec_texts") or []
                        lines.extend(t.strip() for t in rec_texts if t and t.strip())

                    if len(lines) > best_line_count:
                        best_line_count = len(lines)
                        best_text = "\n".join(lines)

                    # Single-language mode: only one candidate, nothing to compare.
                    if len(candidate_langs) == 1:
                        break

                extracted_texts.append(best_text.strip() if best_text else "")

            except Exception as e:
                log_message(
                    f"PaddleOCR (Classic) failed for image {i + 1}: {e}",
                    always_print=True,
                )
                extracted_texts.append("[OCR FAILED]")

        return extracted_texts

    except Exception as e:
        log_message(f"Error with PaddleOCR (Classic): {e}", always_print=True)
        return ["[OCR FAILED]"] * len(images)


def extract_text_with_classic_paddleocr_v5(
    images: List[Image.Image],
    input_language: Optional[str] = None,
    verbose: bool = False,
) -> List[str]:
    """Extract text from images using classic PaddleOCR PP-OCRv5 (mobile),
    NOT PaddleOCR-VL. This is a fast, non-VLM CPU-friendly OCR engine.

    Unlike extract_text_with_classic_paddleocr() (PP-OCRv4), PP-OCRv5's
    default recognition model is a single unified weight file covering
    Simplified Chinese, Traditional Chinese, English, Japanese, and Pinyin
    all at once - so for manga (JP) and manhua (CN, both scripts), no
    per-language selection/loop is needed here.

    Korean is NOT included in that unified model (confirmed upstream:
    PaddlePaddle/PaddleOCR#15373). For Korean input (manhwa), this
    function instead routes to the separate dedicated
    `korean_PP-OCRv5_mobile_rec` model via
    ModelManager.get_paddleocr_classic_v5(korean=True) - still
    PP-OCRv5-generation accuracy, just a different weight file.

    Args:
        images: List of PIL Images to process (RGB)
        input_language: Source language hint (e.g. "Korean", "ko"). Only
            used to decide unified-model vs. Korean-model; any other
            value (or unset/"auto") uses the unified CJK+English+Pinyin
            model, since it covers JP/CN/EN without needing a hint.
        verbose: Whether to print verbose output

    Returns:
        List of extracted text strings (one per image). Returns [OCR FAILED] on errors.
    """
    if not images:
        return []

    try:
        model_manager = get_model_manager()
        use_korean = _normalize_input_language(input_language) == "korean"
        ocr_instance = model_manager.get_paddleocr_classic_v5(
            korean=use_korean, verbose=verbose
        )
        engine_label = "PP-OCRv5, Korean" if use_korean else "PP-OCRv5"

        extracted_texts = []
        for i, img in enumerate(images):
            try:
                if img is None:
                    log_message(
                        f"Image {i + 1} is None (decode failure), skipping",
                        always_print=True,
                    )
                    extracted_texts.append("[OCR FAILED]")
                    continue

                log_message(
                    f"Processing image {i + 1}/{len(images)} with PaddleOCR (Classic, {engine_label})",
                    verbose=verbose,
                )

                img_np = cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)
                result = ocr_instance.predict(img_np)

                lines: List[str] = []
                for res in result or []:
                    res_dict = res if isinstance(res, dict) else getattr(
                        res, "json", {}
                    ).get("res", {})
                    rec_texts = res_dict.get("rec_texts") or []
                    lines.extend(t.strip() for t in rec_texts if t and t.strip())

                text = "\n".join(lines)
                extracted_texts.append(text.strip() if text else "")

            except Exception as e:
                log_message(
                    f"PaddleOCR (Classic, {engine_label}) failed for image {i + 1}: {e}",
                    always_print=True,
                )
                extracted_texts.append("[OCR FAILED]")

        return extracted_texts

    except Exception as e:
        log_message(f"Error with PaddleOCR (Classic, PP-OCRv5): {e}", always_print=True)
        return ["[OCR FAILED]"] * len(images)
